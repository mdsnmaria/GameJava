package controller;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import view.Cenario1CasteloAzul;
import view.Cenario1CasteloNeve;
import view.Cenario1CasteloVerde;
import view.SubFase2;
import view.TelaCenario01Principal;
import view.TelaControle;
import view.Tela_menu;

public class ControllerCen1CasteloAzul extends KeyAdapter implements MouseListener {
	TelaControle telaControle;
	Cenario1CasteloAzul azul;
	TelaCenario01Principal cenario1;
	Tela_menu menu;
	SubFase2 subfase;

	int up, down, left, right;
	int W, S, A, D;
	boolean running = true;
	Thread t;

	public ControllerCen1CasteloAzul(TelaControle controle) {
		this.telaControle = controle;
		this.azul = telaControle.getAzul();
		this.cenario1 = telaControle.getCenario1();
		this.menu= telaControle.getMenu();
		this.subfase= telaControle.getSubfase();

		telaControle.setVisible(true);
		control();

	}

	public void control() {
		azul.addKeyListener(this);
		azul.addMouseListener(this);
		azul.requestFocus();

	}

	public void atualizarTela() {
		azul.getTela().getGraphics().drawImage(azul.getFundo().getCamada(), 0, 0, null);
		azul.getTela().getGraphics().drawImage(azul.getColisao().getCamada(), 0, 0, null);
		azul.getTela().getGraphics().drawImage(azul.getPedras().getCamada(), 0, 0, null);
		azul.getTela().getGraphics().drawImage(azul.getCastelo().getCamada(), 0, 0, null);

		azul.getTela().getGraphics().drawImage(azul.getPersonagem().getSprites()[azul.getPersonagem().getAparecia()],
				azul.getPersonagem().getPosX(), azul.getPersonagem().getPosY(), null);

		azul.getTela().getGraphics().drawImage(azul.getPinheiro().getCamada(), 0, 0, null);

		if (azul.getSeta().isVisivel()) {
			azul.getTela().getGraphics().drawImage(azul.getSeta().getImageObjeto(), azul.getSeta().getPosX(),
					azul.getSeta().getPosY(), null);
		}

		azul.getTela().getGraphics().drawImage(azul.getBotaoExit().getImageObjeto(),
				azul.getBotaoExit().getPosX(), azul.getBotaoExit().getPosY(), null);
		
		if (azul.getOpcoes_sair().isVisivel()) {
			azul.getTela().getGraphics().drawImage(azul.getOpcoes_sair().getImageObjeto(),
					azul.getOpcoes_sair().getPosX(), azul.getOpcoes_sair().getPosY(), null);}

		// evitar pisca pisca: condensa em um unico graphcs
		Graphics2D graphics2d = (Graphics2D) azul.getGraphics();
		graphics2d.drawImage(azul.getTela(), 0, 0, null);

		destravaCaminho();

	}
	
	public void setandoDirecoes() {
		subfase.getPersonagem().setPosX(315);
		subfase.getPersonagem().setPosY(215);
		subfase.getPersonagem().setAparecia(4);

		subfase.getCamEsquerda().setVisivel(true);
		subfase.getPortaEsquerda().setVisivel(true);
		subfase.getSetaEsquerda().setVisivel(true);

		subfase.getCamCima().setVisivel(false);
		subfase.getPortaCima().setVisivel(false);
		subfase.getSetaCima().setVisivel(false);
	}

	public boolean destravaCaminho() {
		Rectangle personagem = azul.getPersonagem().getBounds();
		Rectangle seta = azul.getSeta().getBounds();

		if (personagem.intersects(seta)) {
			azul.getSeta().setVisivel(false);
			cenario1.getCamColor4().setVisivel(true);
			cenario1.getCamIncolor4().setBloqueado(false);
			setandoDirecoes();
			mudarPanels(subfase, azul);
			return true;

		}
		return false;
	}

	public boolean colisaoCastelo() {
		Rectangle personagem = azul.getPersonagem().getBounds();
		List<Rectangle> castAzul = Cenario1CasteloAzul.retangulosColisaoCastelo;

		for (Rectangle rectangle : castAzul) {
			if (rectangle.intersects(personagem)) {
				azul.getPersonagem().setPosX(557);
				azul.getPersonagem().setPosY(80);
			}

		}
		return false;

	}

	public boolean colisaoTronco_e_lateral() {
		List<Rectangle> colisoes = Cenario1CasteloAzul.retangulosColisaoTronco;
		Rectangle personagem = azul.getPersonagem().getBounds();

		for (Rectangle rectangle : colisoes) {
			if (rectangle.intersects(personagem)) {
				return true;
			}
		}
		return false;

	}

	public void mudarPanels(JPanel panel1, JPanel panel2) {
		panel1.setVisible(true);
		panel2.setVisible(false);
		panel1.requestFocus();

	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
			String[] options = { "Sim", "N�o" };
			int respostas = JOptionPane.showOptionDialog(null, "Deseja encerrar o game?", "", JOptionPane.YES_OPTION,
					JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
			if (respostas == JOptionPane.YES_OPTION) {
				System.exit(0);
			}

		}

		if (e.getKeyCode() == KeyEvent.VK_UP) {
			if (!colisaoTronco_e_lateral() && !colisaoCastelo()) {
				azul.getPersonagem().setPosY(azul.getPersonagem().getPosY() - azul.getPersonagem().getVelocidade());
			}
			switch (W) {
			case 0:
				azul.getPersonagem().setAparecia(3);
				break;
			case 1:
				azul.getPersonagem().setAparecia(7);
				break;
			case 2:
				azul.getPersonagem().setAparecia(11);
				break;
			case 3:
				azul.getPersonagem().setAparecia(15);
				break;

			}
			if (W == 3)
				W = 0;
			else
				W++;

			atualizarTela();

		}
		if (e.getKeyCode() == KeyEvent.VK_DOWN) {
			if (!colisaoTronco_e_lateral() && !colisaoCastelo()) {
				azul.getPersonagem().setPosY(azul.getPersonagem().getPosY() + azul.getPersonagem().getVelocidade());
			}
			switch (S) {
			case 0:
				azul.getPersonagem().setAparecia(0);
				break;
			case 1:
				azul.getPersonagem().setAparecia(4);
				break;
			case 2:
				azul.getPersonagem().setAparecia(8);
				break;
			case 3:
				azul.getPersonagem().setAparecia(12);
				break;
			}

			if (S == 3)
				S = 0;
			else
				S++;

			atualizarTela();

		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			if (!colisaoTronco_e_lateral() && !colisaoCastelo()) {
				azul.getPersonagem().setPosX(azul.getPersonagem().getPosX() - azul.getPersonagem().getVelocidade());
			}
			switch (A) {
			case 0:
				azul.getPersonagem().setAparecia(1);
				break;
			case 1:
				azul.getPersonagem().setAparecia(5);
				break;
			case 2:
				azul.getPersonagem().setAparecia(9);
				break;
			case 3:
				azul.getPersonagem().setAparecia(13);
				break;

			}

			if (A == 3)
				A = 0;
			else
				A++;

			atualizarTela();

		}
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			if (!colisaoTronco_e_lateral() && !colisaoCastelo()) {
				azul.getPersonagem().setPosX(azul.getPersonagem().getPosX() + azul.getPersonagem().getVelocidade());
			}
			switch (D) {
			case 0:
				azul.getPersonagem().setAparecia(2);
				break;
			case 1:
				azul.getPersonagem().setAparecia(6);
				break;
			case 2:
				azul.getPersonagem().setAparecia(10);
				break;
			case 3:
				azul.getPersonagem().setAparecia(14);
				break;

			}

			if (D == 3)
				D = 0;
			else
				D++;

			atualizarTela();

		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_UP) {
			if (colisaoTronco_e_lateral())
				azul.getPersonagem().setPosY(azul.getPersonagem().getPosY() + azul.getPersonagem().getVelocidade());
		}
		if (e.getKeyCode() == KeyEvent.VK_DOWN) {
			if (colisaoTronco_e_lateral())
				azul.getPersonagem().setPosY(azul.getPersonagem().getPosY() - azul.getPersonagem().getVelocidade());
		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			if (colisaoTronco_e_lateral())
				azul.getPersonagem().setPosX(azul.getPersonagem().getPosX() + azul.getPersonagem().getVelocidade());

		}
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			if (colisaoTronco_e_lateral())
				azul.getPersonagem().setPosX(azul.getPersonagem().getPosX() - azul.getPersonagem().getVelocidade());

		}

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (((e.getX() >= 611 && e.getX() <= 635)) && ((e.getY() >= 7 && e.getY() <= 33))) {
			azul.getOpcoes_sair().setVisivel(true);
			
		}else {
			azul.getOpcoes_sair().setVisivel(false);
		}
		
		if (((e.getX() >= 345 && e.getX() <= 471)) && ((e.getY() >= 116 && e.getY() <= 157))) {
			mudarPanels(menu, azul);

		}
		if (((e.getX() >= 345 && e.getX() <= 471)) && ((e.getY() >= 178 && e.getY() <= 216))) {
			System.exit(0);
		}

		atualizarTela();
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

}
