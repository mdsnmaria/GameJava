package controller;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.text.TextAction;

import model.Imagens;
import model.PersonagemDragao;
import model.TileMap;
import view.SubFase2;
import view.TelaCenario01Principal;
import view.TelaControle;
import view.TelaFase02;
import view.TelaGanhouJogo;
import view.Tela_menu;

public class ControllerFase02 extends MouseAdapter {
	TelaFase02 fase02;
	TelaControle controle;
	TelaGanhouJogo ganhouJogo;
	int up, down, left, right;
	Tela_menu menu;
	int indiceSetas = 0;
	int contador = 0;
	boolean ativo = true;
	int stop = 0;

	public ControllerFase02(TelaControle controle) {
		this.controle = controle;
		this.fase02 = controle.getFase02();
		this.menu = controle.getMenu();
		this.ganhouJogo= controle.getGanhouJogo();

		controle.setVisible(true);
		controll();
	}

	public void controll() {
		fase02.addMouseListener(this);

	}

	public void atualizarTela() {
		fase02.getTela().getGraphics().drawImage(fase02.getFundo().getCamada(), 0, 0, null);
		fase02.getTela().getGraphics().drawImage(fase02.getCaminho().getCamada(), 0, 0, null);
		fase02.getTela().getGraphics().drawImage(fase02.getCercado().getCamada(), 0, 0, null);
		fase02.getTela().getGraphics().drawImage(fase02.getSaida().getCamada(), 0, 0, null);

		fase02.getTela().getGraphics().drawImage(
				fase02.getPersonagem().getSprites()[fase02.getPersonagem().getAparecia()],
				fase02.getPersonagem().getPosX(), fase02.getPersonagem().getPosY(), null);

		fase02.getTela().getGraphics().drawImage(fase02.getSetaPlay().getImageObjeto(),
				fase02.getSetaPlay().getPosX(), fase02.getSetaPlay().getPosY(), null);
		fase02.getTela().getGraphics().drawImage(fase02.getSetaEsquerda().getImageObjeto(),
				fase02.getSetaEsquerda().getPosX(), fase02.getSetaEsquerda().getPosY(), null);
		fase02.getTela().getGraphics().drawImage(fase02.getSetaDireita().getImageObjeto(),
				fase02.getSetaDireita().getPosX(), fase02.getSetaDireita().getPosY(), null);
		fase02.getTela().getGraphics().drawImage(fase02.getSetaCima().getImageObjeto(),
				fase02.getSetaCima().getPosX(), fase02.getSetaCima().getPosY(), null);
		fase02.getTela().getGraphics().drawImage(fase02.getSetaBaixo().getImageObjeto(),
				fase02.getSetaBaixo().getPosX(), fase02.getSetaBaixo().getPosY(), null);
		fase02.getTela().getGraphics().drawImage(fase02.getSetaExit().getImageObjeto(),
				fase02.getSetaExit().getPosX(), fase02.getSetaExit().getPosY(), null);

		fase02.getTela().getGraphics().drawImage(fase02.getBotaoExit2().getImageObjeto(),
				fase02.getBotaoExit2().getPosX(), fase02.getBotaoExit2().getPosY(), null);

		if (fase02.getOpcoes_sair().isVisivel()) {
			fase02.getTela().getGraphics().drawImage(fase02.getOpcoes_sair().getImageObjeto(),
					fase02.getOpcoes_sair().getPosX(), fase02.getOpcoes_sair().getPosY(), null);

		}

		if (fase02.getAviso_setas().isVisivel()) {
			fase02.getTela().getGraphics().drawImage(fase02.getAviso_setas().getImageObjeto(),
					fase02.getAviso_setas().getPosX(), fase02.getAviso_setas().getPosY(), null);

		}

		if (fase02.getAviso_play().isVisivel()) {
			fase02.getTela().getGraphics().drawImage(fase02.getAviso_play().getImageObjeto(),
					fase02.getAviso_play().getPosX(), fase02.getAviso_play().getPosY(), null);

		}
		
		if (fase02.getExcluir_sem_seta().isVisivel()) {
			fase02.getTela().getGraphics().drawImage(fase02.getExcluir_sem_seta().getImageObjeto(),
					fase02.getExcluir_sem_seta().getPosX(), fase02.getExcluir_sem_seta().getPosY(), null);

		}
	
		for (int i = 0; i < Imagens.getSetas().size(); i++) {
			Imagens setaDireita = Imagens.getSetas().get(i);
			if (setaDireita.isVisivel()) {
				fase02.getTela().getGraphics().drawImage(setaDireita.getImageObjeto(), setaDireita.getPosX(),
						setaDireita.getPosY(), null);
			}
		}
		Graphics2D graphics2d = (Graphics2D) fase02.getGraphics();
		graphics2d.drawImage(fase02.getTela(), 0, 0, null);

	}
	
	public void mudarPanels(JPanel panel1, JPanel panel2) {
		panel1.setVisible(true);
		panel2.setVisible(false);
		panel1.requestFocus();

	}


	public void play() {

		for (int i = 0; i < Imagens.getSetas().size(); i++) {
			Imagens seta = Imagens.getSetas().get(i);
			
			if (i==0) {
				stop = 2 * 8;	
			}else {
				stop= 8;
			}
			ativo=true;
			try {
				Thread.sleep(100);
				switch (seta.getDirecaoSeta()) {
				case 1:
					moverDireita(stop);
					break;
				case 2:
					moverCima(stop);
					break;
				case 3:
					moverEsquerda(stop);
					break;
				case 4:
					moverBaixo(stop);
					break;

				}

			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		atualizarTela();

	}

	
	public void moverDireita(int stop) {

		while (ativo) {
			try {
				Thread.sleep(100);
				if (!colisaoPorta() && !colisaoFundo()) {
					fase02.getPersonagem().setPosX(fase02.getPersonagem().getPosX() + 4);
					contador += 1;

					switch (right) {
					case 0:
						fase02.getPersonagem().setAparecia(2);
						break;
					case 1:
						fase02.getPersonagem().setAparecia(6);
						break;
					case 2:
						fase02.getPersonagem().setAparecia(10);
						break;
					case 3:
						fase02.getPersonagem().setAparecia(14);
						break;

					}

					if (right == 3)
						right = 0;
					else
						right++;

					if (contador == stop) {
						pararMovimento();

					}
				} 
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
			atualizarTela();

		}
	}

	public void moverEsquerda(int stop) {

		while (ativo) {
			try {
				Thread.sleep(100);
				if (!colisaoPorta() && !colisaoFundo()) {
					fase02.getPersonagem().setPosX(fase02.getPersonagem().getPosX() - 4);
					contador += 1;

					switch (left) {
					case 0:
						fase02.getPersonagem().setAparecia(1);
						break;
					case 1:
						fase02.getPersonagem().setAparecia(5);
						break;
					case 2:
						fase02.getPersonagem().setAparecia(9);
						break;
					case 3:
						fase02.getPersonagem().setAparecia(13);
						break;

					}

					if (left == 3)
						left = 0;
					else
						left++;

					if (contador == stop) {
						pararMovimento();

					}
				} 
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
			atualizarTela();

		}
	}

	public void moverCima(int stop) {
		while (ativo) {
			try {
				Thread.sleep(100);
				if (!colisaoPorta() && !colisaoFundo()) {
					fase02.getPersonagem().setPosY(fase02.getPersonagem().getPosY() - 4);
					contador += 1;

					switch (up) {
					case 0:
						fase02.getPersonagem().setAparecia(3);
						break;
					case 1:
						fase02.getPersonagem().setAparecia(7);
						break;
					case 2:
						fase02.getPersonagem().setAparecia(11);
						break;
					case 3:
						fase02.getPersonagem().setAparecia(15);
						break;

					}

					if (up == 3)
						up = 0;
					else
						up++;

					if (contador == stop) {
						pararMovimento();

					}
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
			atualizarTela();
		}

	}


	public void moverBaixo(int stop) {

		while (ativo) {
			try {
				Thread.sleep(100);
				if (!colisaoPorta() && !colisaoFundo()) {
					fase02.getPersonagem().setPosY(fase02.getPersonagem().getPosY() + 4);
					contador += 1;
				}
				switch (down) {
				case 0:
					fase02.getPersonagem().setAparecia(0);
					break;
				case 1:
					fase02.getPersonagem().setAparecia(4);
					break;
				case 2:
					fase02.getPersonagem().setAparecia(8);
					break;
				case 3:
					fase02.getPersonagem().setAparecia(12);
					break;

				}

				if (down == 3)
					down = 0;
				else
					down++;

				if (contador == stop) {
					pararMovimento();

				} 
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
			atualizarTela();
		}
	}
	
	public void exibir_alerta_falta_seta() {

		try {
			fase02.getAviso_setas().setVisivel(true);
			atualizarTela();
			Thread.sleep(3000);
			fase02.getAviso_setas().setVisivel(false);
			atualizarTela();

		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
	
	public void exibir_alerta_excluir_sem_seta() {

		try {
			fase02.getExcluir_sem_seta().setVisivel(true);
			atualizarTela();
			Thread.sleep(3000);
			fase02.getExcluir_sem_seta().setVisivel(false);
			atualizarTela();

		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}
	public void pararMovimento() {
		ativo = false;
		contador = 0;
	}

	public boolean colisaoPorta() {
		Rectangle personagem = fase02.getPersonagem().getBounds();
		List<Rectangle> porta = fase02.retangulosColisaoPorta;

		for (Rectangle rectangle : porta) {
			if (rectangle.intersects(personagem)) {
				reiniciar();
				mudarPanels(ganhouJogo, fase02);
				
			}
		}
		return false;

	}

	public boolean colisaoFundo() {
		List<Rectangle> fundo = fase02.retangulosColisaoFundo;
		Rectangle personagem = fase02.getPersonagem().getBounds();

		for (Rectangle rectangle : fundo) {
			if (rectangle.intersects(personagem)) {
				seColidir();
				return true;
			}
		}
		return false;
	}

	public void seColidir() {
		ativo = false;
		reiniciar();
		fase02.getPersonagem().setPosX(285);
		fase02.getPersonagem().setPosY(150);
		fase02.getPersonagem().setAparecia(4);
		
	}

	public void reiniciar() {
		Imagens.getSetas().clear();
		indiceSetas = 0;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
//		System.out.println("x" + e.getX());
//		System.out.println("y" + e.getY());

		// Seta direita
		if (((e.getX() >= 337 && e.getX() <= 361)) && ((e.getY() >= 403 && e.getY() <= 424))) {
			if (fase02.getSetaDireita().isVisivel()) {
				Imagens.getSetas().add(new Imagens("/res/direita.png", Imagens.getFase2posXdireitaCorreta()[indiceSetas],
						Imagens.getFase2posYdireitaCorreta()[indiceSetas], 32, 32, true, 1));
				indiceSetas++;
			}

		}
		// seta esquerda
		if (((e.getX() >= 288 && e.getX() <= 312)) && ((e.getY() >= 403 && e.getY() <= 424))) {
			if (fase02.getSetaEsquerda().isVisivel()) {
				Imagens.getSetas()
						.add(new Imagens("/res/esquerda.png", Imagens.getFase2posXesquerdaCorreta()[indiceSetas],
								Imagens.getFase2posYesquerdaCorreta()[indiceSetas], 32, 32, true, 3));
				indiceSetas++;

			}
		}
		// setaCima
		if (((e.getX() >= 390 && e.getX() <= 410)) && ((e.getY() >= 403 && e.getY() <= 424))) {
			if (fase02.getSetaCima().isVisivel()) {
				Imagens.getSetas().add(new Imagens("/res/cima.png", Imagens.getFase2posXcimaCorreta()[indiceSetas],
						Imagens.getFase2posYcimaCorreta()[indiceSetas], 32, 32, true, 2));
				indiceSetas++;

			}
		}
		// seta baixo
		if (((e.getX() >= 437 && e.getX() <= 460)) && ((e.getY() >= 403 && e.getY() <= 424))) {
			if (fase02.getSetaBaixo().isVisivel()) {
				Imagens.getSetas().add(new Imagens("/res/baixo.png", Imagens.getFase2posXbaixoCorreta()[indiceSetas],
						Imagens.getFase2posYbaixoCorreta()[indiceSetas], 32, 32, true, 4));
				indiceSetas++;

			}
		}

		//play
		if (((e.getX() >= 236 && e.getX() <= 262)) && ((e.getY() >= 403 && e.getY() <= 424))) {
				if (Imagens.getSetas().size() < 16) {
					exibir_alerta_falta_seta();
					reiniciar();
				}
				else {
					ativo = true;
					play();
				}
			
		} else {
			fase02.getAviso_setas().setVisivel(false);
		}
		//excluir ultima seta
		if (((e.getX() >= 486 && e.getX() <= 514)) && ((e.getY() >= 403 && e.getY() <= 424))) {
			if (Imagens.getSetas().size()!= 0) {
				Imagens.getSetas().remove(Imagens.getSetas().size()-1);
				indiceSetas--;
				
			}else {
				exibir_alerta_excluir_sem_seta();
			}
		}

		// icone de sair
		if (((e.getX() >= 592 && e.getX() <= 620)) && ((e.getY() >= 10 && e.getY() <= 39))) {
			fase02.getOpcoes_sair().setVisivel(true);
		} else {
			fase02.getOpcoes_sair().setVisivel(false);
		}
		// opcao de menu
		if (((e.getX() >= 345 && e.getX() <= 471)) && ((e.getY() >= 116 && e.getY() <= 157))) {
			mudarPanels(menu, fase02);
		}
		// opcao sair
		if (((e.getX() >= 345 && e.getX() <= 471)) && ((e.getY() >= 178 && e.getY() <= 216))) {
			System.exit(0);
		}
		atualizarTela();
	}
}
