package controller;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import model.Inimigo;
import model.Sprite;
import view.Cenario1CasteloNeve;
import view.Cenario1CasteloVerde;
import view.SubFase2;
import view.TelaCenario01Principal;
import view.TelaControle;
import view.Tela_menu;

public class ControllerCen1CasteloVerd extends KeyAdapter implements MouseListener {
	TelaControle telaControle;
	Cenario1CasteloVerde verde;
	TelaCenario01Principal cenario1;
	SubFase2 subFase;
	Tela_menu menu;

	int up, down, left, right;
	int W, S, A, D;
	boolean running = true;

	public ControllerCen1CasteloVerd(TelaControle telaControle) {
		this.telaControle = telaControle;
		this.verde = telaControle.getVerde();
		this.cenario1 = telaControle.getCenario1();
		this.subFase = telaControle.getSubfase();
		this.menu = telaControle.getMenu();

		telaControle.setVisible(true);
		control();

	}

	public void control() {
		verde.addKeyListener(this);
		verde.addMouseListener(this);
		verde.requestFocus();

	}

	public void atualizarTela() {

		verde.getTela().getGraphics().drawImage(verde.getFundo().getCamada(), 0, 0, null);
		verde.getTela().getGraphics().drawImage(verde.getColisao().getCamada(), 0, 0, null);
		verde.getTela().getGraphics().drawImage(verde.getPedras().getCamada(), 0, 0, null);

		verde.getTela().getGraphics().drawImage(verde.getCastelo().getCamada(), 0, 0, null);

		for (Sprite inim : verde.getInimigos()) {
			verde.getTela().getGraphics().drawImage(inim.getSprites()[inim.getAparecia()], inim.getPosX(),
					inim.getPosY(), null);

		}

		verde.getTela().getGraphics().drawImage(verde.getPersonagem().getSprites()[verde.getPersonagem().getAparecia()],
				verde.getPersonagem().getPosX(), verde.getPersonagem().getPosY(), null);

		verde.getTela().getGraphics().drawImage(verde.getPinheiro().getCamada(), 0, 0, null);

		if (verde.getSeta().isVisivel()) {
			verde.getTela().getGraphics().drawImage(verde.getSeta().getImageObjeto(),
					verde.getSeta().getPosX(), verde.getSeta().getPosY(), null);
		}

		verde.getTela().getGraphics().drawImage(verde.getBotaoExit().getImageObjeto(),
				verde.getBotaoExit().getPosX(), verde.getBotaoExit().getPosY(), null);

		if (verde.getOpcoes_sair().isVisivel()) {
			verde.getTela().getGraphics().drawImage(verde.getOpcoes_sair().getImageObjeto(),
					verde.getOpcoes_sair().getPosX(), verde.getOpcoes_sair().getPosY(), null);
		}

		// evitar pisca pisca: condensa em um unico graphcs
		Graphics2D graphics2d = (Graphics2D) verde.getGraphics();
		graphics2d.drawImage(verde.getTela(), 0, 0, null);

		destravaCaminho();

	}

	public boolean destravaCaminho() {
		Rectangle personagem = verde.getPersonagem().getBounds();
		Rectangle seta = verde.getSeta().getBounds();

		if (personagem.intersects(seta)) {
			verde.getSeta().setVisivel(false);
			cenario1.getCamIncolor2().setBloqueado(false);
			cenario1.getCamColor2().setVisivel(true);
			mudarPanels(subFase, verde);
			return true;

		}
		return false;
	}

	public boolean colisaoCenarioVerd() {
		List<Rectangle> castelo = Cenario1CasteloVerde.retangulosColisaoCastelo;
		Rectangle personagem = verde.getPersonagem().getBounds();

		for (Rectangle castel : castelo) {
			if (castel.intersects(personagem)) {
				verde.getPersonagem().setPosX(557);
				verde.getPersonagem().setPosY(80);

			}

			for (Inimigo inim : verde.getInimigos()) {
				if (personagem.intersects(inim.getBounds())) {
					mudarPanels(cenario1, verde);
					cenario1.getPersonagem().setPosX(283);
					cenario1.getPersonagem().setPosY(187);

				}
			}
		}

		return false;

	}

	public boolean colisaoTronco_e_lateral() {
		List<Rectangle> colisoes = Cenario1CasteloVerde.retangulosColisaoTronco;
		Rectangle personagem = verde.getPersonagem().getBounds();

		for (Rectangle rectangle : colisoes) {
			if (rectangle.intersects(personagem)) {
				return true;
			}
		}
		return false;

	}

	public void mudarPanels(JPanel panel1, JPanel panel2) {
		panel1.setVisible(true);
		panel2.setVisible(false);
		panel1.requestFocus();

	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
			String[] options = { "Sim", "N�o" };
			int respostas = JOptionPane.showOptionDialog(null, "Deseja encerrar o game?", "", JOptionPane.YES_OPTION,
					JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
			if (respostas == JOptionPane.YES_OPTION) {
				System.exit(0);
			}

		}

		if (e.getKeyCode() == KeyEvent.VK_UP) {

			if (!colisaoTronco_e_lateral() && !colisaoCenarioVerd()) {
				verde.getPersonagem().setPosY(verde.getPersonagem().getPosY() - verde.getPersonagem().getVelocidade());
			}

			switch (W) {
			case 0:
				verde.getPersonagem().setAparecia(3);
				break;
			case 1:
				verde.getPersonagem().setAparecia(7);
				break;
			case 2:
				verde.getPersonagem().setAparecia(11);
				break;
			case 3:
				verde.getPersonagem().setAparecia(15);
				break;

			}
			if (W == 3)
				W = 0;
			else
				W++;

			atualizarTela();

		}
		if (e.getKeyCode() == KeyEvent.VK_DOWN) {
			if (!colisaoTronco_e_lateral() && !colisaoCenarioVerd()) {
				verde.getPersonagem().setPosY(verde.getPersonagem().getPosY() + verde.getPersonagem().getVelocidade());
			}
			switch (S) {
			case 0:
				verde.getPersonagem().setAparecia(0);
				break;
			case 1:
				verde.getPersonagem().setAparecia(4);
				break;
			case 2:
				verde.getPersonagem().setAparecia(8);
				break;
			case 3:
				verde.getPersonagem().setAparecia(12);
				break;
			}

			if (S == 3)
				S = 0;
			else
				S++;

			atualizarTela();

		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			if (!colisaoTronco_e_lateral() && !colisaoCenarioVerd()) {
				verde.getPersonagem().setPosX(verde.getPersonagem().getPosX() - verde.getPersonagem().getVelocidade());
			}
			switch (A) {
			case 0:
				verde.getPersonagem().setAparecia(1);
				break;
			case 1:
				verde.getPersonagem().setAparecia(5);
				break;
			case 2:
				verde.getPersonagem().setAparecia(9);
				break;
			case 3:
				verde.getPersonagem().setAparecia(13);
				break;

			}

			if (A == 3)
				A = 0;
			else
				A++;

			atualizarTela();

		}
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			if (!colisaoTronco_e_lateral() && !colisaoCenarioVerd()) {
				verde.getPersonagem().setPosX(verde.getPersonagem().getPosX() + verde.getPersonagem().getVelocidade());
			}
			switch (D) {
			case 0:
				verde.getPersonagem().setAparecia(2);
				break;
			case 1:
				verde.getPersonagem().setAparecia(6);
				break;
			case 2:
				verde.getPersonagem().setAparecia(10);
				break;
			case 3:
				verde.getPersonagem().setAparecia(14);
				break;

			}

			if (D == 3)
				D = 0;
			else
				D++;

			atualizarTela();
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_UP) {
			if (colisaoTronco_e_lateral())
				verde.getPersonagem().setPosY(verde.getPersonagem().getPosY() + verde.getPersonagem().getVelocidade());
		}
		if (e.getKeyCode() == KeyEvent.VK_DOWN) {
			if (colisaoTronco_e_lateral())
				verde.getPersonagem().setPosY(verde.getPersonagem().getPosY() - verde.getPersonagem().getVelocidade());
		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			if (colisaoTronco_e_lateral())
				verde.getPersonagem().setPosX(verde.getPersonagem().getPosX() + verde.getPersonagem().getVelocidade());

		}
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			if (colisaoTronco_e_lateral())
				verde.getPersonagem().setPosX(verde.getPersonagem().getPosX() - verde.getPersonagem().getVelocidade());

		}

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		System.out.println("x" + e.getX());
		System.out.println("x" + e.getY());
		if (((e.getX() >= 611 && e.getX() <= 635)) && ((e.getY() >= 7 && e.getY() <= 33))) {
			verde.getOpcoes_sair().setVisivel(true);
		} else {
			verde.getOpcoes_sair().setVisivel(false);
		}

		if (((e.getX() >= 345 && e.getX() <= 471)) && ((e.getY() >= 116 && e.getY() <= 157))) {
			mudarPanels(menu, verde);

		}
		if (((e.getX() >= 345 && e.getX() <= 471)) && ((e.getY() >= 178 && e.getY() <= 216))) {
			System.exit(0);
		}

		atualizarTela();
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}
}
