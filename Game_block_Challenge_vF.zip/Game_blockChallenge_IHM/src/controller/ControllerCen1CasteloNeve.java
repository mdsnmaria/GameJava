package controller;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import view.Cenario1CasteloAzul;
import view.Cenario1CasteloNeve;
import view.Cenario1CasteloVerde;
import view.SubFase2;
import view.TelaCenario01Principal;
import view.TelaControle;
import view.Tela_menu;

public class ControllerCen1CasteloNeve extends KeyAdapter implements MouseListener {
	TelaControle telaControle;
	Cenario1CasteloNeve neve;
	TelaCenario01Principal cenario1;
	Tela_menu menu;
	SubFase2 subfase;

	int up, down, left, right;
	int W, S, A, D;

	public ControllerCen1CasteloNeve(TelaControle controle) {
		this.telaControle = controle;
		this.neve = telaControle.getNeve();
		this.cenario1 = telaControle.getCenario1();
		this.menu = telaControle.getMenu();
		this.subfase = telaControle.getSubfase();
		telaControle.setVisible(true);
		control();

	}

	public void control() {
		neve.addKeyListener(this);
		neve.addMouseListener(this);
		neve.requestFocus();

	}

	public void atualizarTela() {
		neve.getTela().getGraphics().drawImage(neve.getFundo().getCamada(), 0, 0, null);
		neve.getTela().getGraphics().drawImage(neve.getColisao().getCamada(), 0, 0, null);
		neve.getTela().getGraphics().drawImage(neve.getColisaoTronco().getCamada(), 0, 0, null);
		neve.getTela().getGraphics().drawImage(neve.getPedras().getCamada(), 0, 0, null);
		neve.getTela().getGraphics().drawImage(neve.getCastelo().getCamada(), 0, 0, null);

		neve.getTela().getGraphics().drawImage(neve.getPersonagem().getSprites()[neve.getPersonagem().getAparecia()],
				neve.getPersonagem().getPosX(), neve.getPersonagem().getPosY(), null);

		neve.getTela().getGraphics().drawImage(neve.getPinheiro().getCamada(), 0, 0, null);

		if (neve.getSeta().isVisivel()) {
			neve.getTela().getGraphics().drawImage(neve.getSeta().getImageObjeto(), neve.getSeta().getPosX(),
					neve.getSeta().getPosY(), null);
		}

		neve.getTela().getGraphics().drawImage(neve.getBotaoExit().getImageObjeto(),
				neve.getBotaoExit().getPosX(), neve.getBotaoExit().getPosY(), null);

		if (neve.getOpcoes_sair().isVisivel()) {
			neve.getTela().getGraphics().drawImage(neve.getOpcoes_sair().getImageObjeto(),
					neve.getOpcoes_sair().getPosX(), neve.getOpcoes_sair().getPosY(), null);
		}

		// evitar pisca pisca: condensa em um unico graphcs
		Graphics2D graphics2d = (Graphics2D) neve.getGraphics();
		graphics2d.drawImage(neve.getTela(), 0, 0, null);

		destravaCaminho();

	}

	public void setandoDirecoes() {
		subfase.getPersonagem().setPosX(315);
		subfase.getPersonagem().setPosY(215);
		subfase.getPersonagem().setAparecia(4);

		subfase.getCamBaixo().setVisivel(true);
		subfase.getPortaBaixo().setVisivel(true);
		subfase.getSetaBaixo().setVisivel(true);

		subfase.getCamEsquerda().setVisivel(false);
		subfase.getPortaEsquerda().setVisivel(false);
		subfase.getSetaEsquerda().setVisivel(false);
	}

	public boolean destravaCaminho() {
		Rectangle personagem = neve.getPersonagem().getBounds();
		Rectangle seta = neve.getSeta().getBounds();

		if (personagem.intersects(seta)) {
			neve.getSeta().setVisivel(false);
			cenario1.getCaminhoColorCompleto().setVisivel(true);
			setandoDirecoes();
			mudarPanels(subfase, neve);
			return true;

		}
		return false;
	}

	public boolean colisaoTronco_e_lateral() {
		// aqui foi verificado 2 colisoes pq o cenario foi feito em um tileset e a parte
		// do tronco em outro
		List<Rectangle> colisoesTronco = Cenario1CasteloNeve.retangulosColisaoTronco;
		List<Rectangle> colisoesCenario = Cenario1CasteloNeve.retangulosColisaoCenario;
		Rectangle personagem = neve.getPersonagem().getBounds();

		for (Rectangle cenario : colisoesCenario) {
			if (cenario.intersects(personagem)) {
				return true;
			}
		}

		for (Rectangle tronco : colisoesTronco) {
			if (tronco.intersects(personagem)) {
				return true;
			}
		}
		return false;

	}

	public boolean colisaoCastelo() {
		Rectangle personagem = neve.getPersonagem().getBounds();
		List<Rectangle> castNeve = Cenario1CasteloNeve.retangulosColisaoCastelo;
		for (Rectangle rectangle : castNeve) {
			if (rectangle.intersects(personagem)) {
				neve.getPersonagem().setPosX(557);
				neve.getPersonagem().setPosY(80);

			}

		}
		return false;

	}

	public void mudarPanels(JPanel panel1, JPanel panel2) {
		panel1.setVisible(true);
		panel2.setVisible(false);
		panel1.requestFocus();

	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
			String[] options = { "Sim", "N�o" };
			int respostas = JOptionPane.showOptionDialog(null, "Deseja encerrar o game?", "", JOptionPane.YES_OPTION,
					JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
			if (respostas == JOptionPane.YES_OPTION) {
				System.exit(0);
			}

		}

		if (e.getKeyCode() == KeyEvent.VK_UP) {
			if (!colisaoTronco_e_lateral() && !colisaoCastelo()) {
				neve.getPersonagem().setPosY(neve.getPersonagem().getPosY() - cenario1.getPersonagem().getVelocidade());
			}
			switch (W) {
			case 0:
				neve.getPersonagem().setAparecia(3);
				break;
			case 1:
				neve.getPersonagem().setAparecia(7);
				break;
			case 2:
				neve.getPersonagem().setAparecia(11);
				break;
			case 3:
				neve.getPersonagem().setAparecia(15);
				break;

			}
			if (W == 3)
				W = 0;
			else
				W++;

			atualizarTela();

		}
		if (e.getKeyCode() == KeyEvent.VK_DOWN) {
			if (!colisaoTronco_e_lateral() && !colisaoCastelo()) {
				neve.getPersonagem().setPosY(neve.getPersonagem().getPosY() + cenario1.getPersonagem().getVelocidade());
			}
			switch (S) {
			case 0:
				neve.getPersonagem().setAparecia(0);
				break;
			case 1:
				neve.getPersonagem().setAparecia(4);
				break;
			case 2:
				neve.getPersonagem().setAparecia(8);
				break;
			case 3:
				neve.getPersonagem().setAparecia(12);
				break;
			}

			if (S == 3)
				S = 0;
			else
				S++;

			atualizarTela();

		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			if (!colisaoTronco_e_lateral() && !colisaoCastelo()) {
				neve.getPersonagem().setPosX(neve.getPersonagem().getPosX() - neve.getPersonagem().getVelocidade());
			}
			switch (A) {
			case 0:
				neve.getPersonagem().setAparecia(1);
				break;
			case 1:
				neve.getPersonagem().setAparecia(5);
				break;
			case 2:
				neve.getPersonagem().setAparecia(9);
				break;
			case 3:
				neve.getPersonagem().setAparecia(13);
				break;

			}

			if (A == 3)
				A = 0;
			else
				A++;

			atualizarTela();

		}
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			if (!colisaoTronco_e_lateral() && !colisaoCastelo()) {
				neve.getPersonagem().setPosX(neve.getPersonagem().getPosX() + cenario1.getPersonagem().getVelocidade());
			}
			switch (D) {
			case 0:
				neve.getPersonagem().setAparecia(2);
				break;
			case 1:
				neve.getPersonagem().setAparecia(6);
				break;
			case 2:
				neve.getPersonagem().setAparecia(10);
				break;
			case 3:
				neve.getPersonagem().setAparecia(14);
				break;

			}

			if (D == 3)
				D = 0;
			else
				D++;

			atualizarTela();
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_UP) {
			if (colisaoTronco_e_lateral())
				neve.getPersonagem().setPosY(neve.getPersonagem().getPosY() + neve.getPersonagem().getVelocidade());
		}
		if (e.getKeyCode() == KeyEvent.VK_DOWN) {
			if (colisaoTronco_e_lateral())
				neve.getPersonagem().setPosY(neve.getPersonagem().getPosY() - neve.getPersonagem().getVelocidade());
		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			if (colisaoTronco_e_lateral())
				neve.getPersonagem().setPosX(neve.getPersonagem().getPosX() + neve.getPersonagem().getVelocidade());

		}
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			if (colisaoTronco_e_lateral())
				neve.getPersonagem().setPosX(neve.getPersonagem().getPosX() - neve.getPersonagem().getVelocidade());

		}

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (((e.getX() >= 611 && e.getX() <= 635)) && ((e.getY() >= 7 && e.getY() <= 33))) {
			neve.getOpcoes_sair().setVisivel(true);

		} else {
			neve.getOpcoes_sair().setVisivel(false);
		}

		if (((e.getX() >= 345 && e.getX() <= 471)) && ((e.getY() >= 116 && e.getY() <= 157))) {
			mudarPanels(menu, neve);
		}
		if (((e.getX() >= 345 && e.getX() <= 471)) && ((e.getY() >= 178 && e.getY() <= 216))) {
			System.exit(0);
		}

		atualizarTela();

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}
}
