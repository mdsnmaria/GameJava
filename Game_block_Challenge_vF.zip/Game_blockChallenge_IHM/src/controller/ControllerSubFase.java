package controller;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import model.Imagens;
import view.TelaCenario01Principal;
import view.TelaControle;
import view.TelaFase02;
import view.Tela_menu;
import view.Cenario1CasteloAzul;
import view.SubFase2;

public class ControllerSubFase extends MouseAdapter {
	TelaControle telaControle;
	SubFase2 subfase;
	TelaCenario01Principal cenario1;
	Tela_menu menu;
	TelaFase02 fase02;
	int indiceSetas = 0;
	int up, down, left, right;
	int contador = 0;
	boolean ativo = true;
	int stop = 0;

	public ControllerSubFase(TelaControle controle) {
		this.telaControle = controle;
		this.subfase = telaControle.getSubfase();
		this.cenario1 = telaControle.getCenario1();
		this.menu = telaControle.getMenu();
		this.fase02= telaControle.getFase02();
		telaControle.setVisible(true);
		control();
	}

	public void control() {
		subfase.addMouseListener(this);

	}

	public void mudarPanels(JPanel panel1, JPanel panel2) {
		panel1.setVisible(true);
		panel2.setVisible(false);
		panel1.requestFocus();

	}

	void atualizarTela() {
		subfase.getTela().getGraphics().drawImage(subfase.getFundo().getCamada(), 0, 0, null);
		if (subfase.getCamDireita().isVisivel()) {
			subfase.getTela().getGraphics().drawImage(subfase.getCamDireita().getCamada(), 0, 0, null);
		}

		if (subfase.getCamEsquerda().isVisivel()) {
			subfase.getTela().getGraphics().drawImage(subfase.getCamEsquerda().getCamada(), 0, 0, null);
		}
		if (subfase.getCamCima().isVisivel()) {
			subfase.getTela().getGraphics().drawImage(subfase.getCamCima().getCamada(), 0, 0, null);
		}
		if (subfase.getCamBaixo().isVisivel()) {
			subfase.getTela().getGraphics().drawImage(subfase.getCamBaixo().getCamada(), 0, 0, null);
		}
		if (subfase.getPortaDireita().isVisivel()) {
			subfase.getTela().getGraphics().drawImage(subfase.getPortaDireita().getCamada(), 0, 0, null);
		}
		if (subfase.getPortaEsquerda().isVisivel()) {
			subfase.getTela().getGraphics().drawImage(subfase.getPortaEsquerda().getCamada(), 0, 0, null);
		}
		if (subfase.getPortaCima().isVisivel()) {
			subfase.getTela().getGraphics().drawImage(subfase.getPortaCima().getCamada(), 0, 0, null);
		}
		if (subfase.getPortaBaixo().isVisivel()) {
			subfase.getTela().getGraphics().drawImage(subfase.getPortaBaixo().getCamada(), 0, 0, null);
		}

		subfase.getTela().getGraphics().drawImage(
				subfase.getPersonagem().getSprites()[subfase.getPersonagem().getAparecia()],
				subfase.getPersonagem().getPosX(), subfase.getPersonagem().getPosY(), null);

		if (subfase.getSetaDireita().isVisivel()) {
			subfase.getTela().getGraphics().drawImage(subfase.getSetaDireita().getImageObjeto(),
					subfase.getSetaDireita().getPosX(), subfase.getSetaDireita().getPosY(), null);

		}

		if (subfase.getSetaCima().isVisivel()) {
			subfase.getTela().getGraphics().drawImage(subfase.getSetaCima().getImageObjeto(),
					subfase.getSetaCima().getPosX(), subfase.getSetaCima().getPosY(), null);

		}

		if (subfase.getSetaEsquerda().isVisivel()) {
			subfase.getTela().getGraphics().drawImage(subfase.getSetaEsquerda().getImageObjeto(),
					subfase.getSetaEsquerda().getPosX(), subfase.getSetaEsquerda().getPosY(), null);

		}

		if (subfase.getSetaBaixo().isVisivel()) {
			subfase.getTela().getGraphics().drawImage(subfase.getSetaBaixo().getImageObjeto(),
					subfase.getSetaBaixo().getPosX(), subfase.getSetaBaixo().getPosY(), null);

		}

		subfase.getTela().getGraphics().drawImage(subfase.getBotaoPlay().getImageObjeto(),
				subfase.getBotaoPlay().getPosX(), subfase.getBotaoPlay().getPosY(), null);

		subfase.getTela().getGraphics().drawImage(subfase.getBotaoExit().getImageObjeto(),
				subfase.getBotaoExit().getPosX(), subfase.getBotaoExit().getPosY(), null);

		if (subfase.getOpcoes_sair().isVisivel()) {
			subfase.getTela().getGraphics().drawImage(subfase.getOpcoes_sair().getImageObjeto(),
					subfase.getOpcoes_sair().getPosX(), subfase.getOpcoes_sair().getPosY(), null);

		}

		if (subfase.getAviso_setas().isVisivel()) {
			subfase.getTela().getGraphics().drawImage(subfase.getAviso_setas().getImageObjeto(),
					subfase.getAviso_setas().getPosX(), subfase.getAviso_setas().getPosY(), null);

		}

		if (subfase.getAviso_play().isVisivel()) {
			subfase.getTela().getGraphics().drawImage(subfase.getAviso_play().getImageObjeto(),
					subfase.getAviso_play().getPosX(), subfase.getAviso_play().getPosY(), null);

		}

		for (int i = 0; i < Imagens.getSetas().size(); i++) {
			Imagens setaDireita = Imagens.getSetas().get(i);
			if (setaDireita.isVisivel()) {
				subfase.getTela().getGraphics().drawImage(setaDireita.getImageObjeto(),
						setaDireita.getPosX(), setaDireita.getPosY(), null);
			}
		}

		Graphics2D graphics2d = (Graphics2D) subfase.getGraphics();
		graphics2d.drawImage(subfase.getTela(), 0, 0, null);
	}

	public boolean colisaoPorta() {
		Rectangle personagem = subfase.getPersonagem().getBounds();
		List<Rectangle> portaDireita = SubFase2.retangulosColisaoPortaDireita;
		List<Rectangle> portaEsquerda = SubFase2.retangulosColisaoPortaEsquerda;
		List<Rectangle> portaCima = SubFase2.retangulosColisaoPortaCima;
		List<Rectangle> portaBaixo = SubFase2.retangulosColisaoPortaBaixo;
		
		for (Rectangle rectangle : portaDireita) {
			if (rectangle.intersects(personagem)) {
				mudarPanels(cenario1, subfase);
				cenario1.getPersonagem().setPosX(283);
				cenario1.getPersonagem().setPosY(187);
				cenario1.getPersonagem().setAparecia(0);
				reiniciar();
			}
		}
		
		for (Rectangle rectangle : portaEsquerda) {
			if (rectangle.intersects(personagem)) {
				mudarPanels(cenario1, subfase);
				cenario1.getPersonagem().setPosX(283);
				cenario1.getPersonagem().setPosY(187);
				cenario1.getPersonagem().setAparecia(0);
				reiniciar();
			}
		}
		for (Rectangle rectangle : portaCima) {
			if (rectangle.intersects(personagem)) {
				mudarPanels(cenario1, subfase);
				cenario1.getPersonagem().setPosX(283);
				cenario1.getPersonagem().setPosY(187);
				cenario1.getPersonagem().setAparecia(0);
				reiniciar();
			}
		}
		for (Rectangle rectangle : portaBaixo) {
			if (rectangle.intersects(personagem)) {
				mudarPanels(fase02, subfase);
				reiniciar();
			}
		}
		return false;

	}

	public void play() {
		int tamanho = Imagens.getSetas().size();
		stop = (tamanho + 1) * 8;
		for (int i = 0; i < Imagens.getSetas().size(); i++) {
			Imagens seta = Imagens.getSetas().get(i);

			try {
				Thread.sleep(100);
				switch (seta.getDirecaoSeta()) {
				case 1:
					moverDireita();

					break;
				case 2:
					moverCima();
					break;
				case 3:
					moverEsquerda();
					break;
				case 4:
					moverBaixo();
					break;

				}

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		atualizarTela();

	}

	public void pararMovimento() {
		ativo = false;
		contador = 0;
	}

	public void moverDireita() {

		while (ativo) {
			try {
				Thread.sleep(100);
				if (!colisaoPorta()) {
					subfase.getPersonagem().setPosX(subfase.getPersonagem().getPosX() + 4);
					contador += 1;

					switch (right) {
					case 0:
						subfase.getPersonagem().setAparecia(2);
						break;
					case 1:
						subfase.getPersonagem().setAparecia(6);
						break;
					case 2:
						subfase.getPersonagem().setAparecia(10);
						break;
					case 3:
						subfase.getPersonagem().setAparecia(14);
						break;

					}

					if (right == 3)
						right = 0;
					else
						right++;

					if (contador == stop) {
						pararMovimento();

					}
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
			atualizarTela();

		}
	}

	public void moverEsquerda() {

		while (ativo) {
			try {
				Thread.sleep(100);
				if (!colisaoPorta()) {
					subfase.getPersonagem().setPosX(subfase.getPersonagem().getPosX() - 4);
					contador += 1;

					switch (left) {
					case 0:
						subfase.getPersonagem().setAparecia(1);
						break;
					case 1:
						subfase.getPersonagem().setAparecia(5);
						break;
					case 2:
						subfase.getPersonagem().setAparecia(9);
						break;
					case 3:
						subfase.getPersonagem().setAparecia(13);
						break;

					}

					if (left == 3)
						left = 0;
					else
						left++;

					if (contador == stop) {
						pararMovimento();

					}
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
			atualizarTela();

		}
	}

	public void moverCima() {
		System.out.println(ativo);

		while (ativo) {
			try {
				Thread.sleep(100);
				if (!colisaoPorta()) {
					subfase.getPersonagem().setPosY(subfase.getPersonagem().getPosY() - 4);
					contador += 1;

					switch (up) {
					case 0:
						subfase.getPersonagem().setAparecia(3);
						break;
					case 1:
						subfase.getPersonagem().setAparecia(7);
						break;
					case 2:
						subfase.getPersonagem().setAparecia(11);
						break;
					case 3:
						subfase.getPersonagem().setAparecia(15);
						break;

					}

					if (up == 3)
						up = 0;
					else
						up++;

					if (contador == stop) {
						pararMovimento();

					}
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
			atualizarTela();
		}

	}

	public void exibir_alerta() {

		try {
			subfase.getAviso_setas().setVisivel(true);
			atualizarTela();
			Thread.sleep(3000);
			subfase.getAviso_setas().setVisivel(false);
			atualizarTela();
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		

	}

	public void moverBaixo() {

		while (ativo) {
			try {
				Thread.sleep(100);
				if (!colisaoPorta()) {
					subfase.getPersonagem().setPosY(subfase.getPersonagem().getPosY() + 4);
					contador += 1;
				}
				switch (down) {
				case 0:
					subfase.getPersonagem().setAparecia(0);
					break;
				case 1:
					subfase.getPersonagem().setAparecia(4);
					break;
				case 2:
					subfase.getPersonagem().setAparecia(8);
					break;
				case 3:
					subfase.getPersonagem().setAparecia(12);
					break;

				}

				if (down == 3)
					down = 0;
				else
					down++;

				if (contador == stop) {
					pararMovimento();

				}
				atualizarTela();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}

		}
	}

	public void reiniciar() {
		Imagens.getSetas().clear();
		indiceSetas = 0;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
//		System.out.println("x" + e.getX());
//		System.out.println("y" + e.getY());

		// Seta
		if (((e.getX() >= 452 && e.getX() <= 477)) && ((e.getY() >= 374 && e.getY() <= 397))) {
			if (subfase.getSetaDireita().isVisivel()) {
				Imagens.getSetas().add(new Imagens("/res/direita.png", Imagens.getPosiXdireita()[indiceSetas],
						Imagens.getPosiYdireita()[indiceSetas], 32, 32, true, 1));
				indiceSetas++;
			} else if (subfase.getSetaCima().isVisivel()) {
				Imagens.getSetas().add(new Imagens("/res/cima.png", Imagens.getPosiXcima()[indiceSetas],
						Imagens.getPosiYcima()[indiceSetas], 32, 32, true, 2));
				indiceSetas++;

			} else if (subfase.getSetaEsquerda().isVisivel()) {
				Imagens.getSetas().add(new Imagens("/res/esquerda.png", Imagens.getPosiXesquerda()[indiceSetas],
						Imagens.getPosiYesquerda()[indiceSetas], 32, 32, true, 3));
				indiceSetas++;

			}		
			else if (subfase.getSetaBaixo().isVisivel()) {
				Imagens.getSetas().add(new Imagens("/res/baixo.png", Imagens.getPosiXBaixo()[indiceSetas],
						Imagens.getPosiYBaixo()[indiceSetas], 32, 32, true, 4));
				indiceSetas++;

			}

		}

		if (((e.getX() >= 485 && e.getX() <= 511)) && ((e.getY() >= 371 && e.getY() <= 398))) {
//			subfase.getAviso_play().setVisivel(true);
			if (Imagens.getSetas().size() < 6 && subfase.getSetaDireita().isVisivel()) {
				exibir_alerta();
				reiniciar();
			} else if (Imagens.getSetas().size() < 4 && subfase.getSetaCima().isVisivel()) {
				exibir_alerta();
				reiniciar();
			} else if (Imagens.getSetas().size() < 6 && subfase.getSetaEsquerda().isVisivel()) {
				exibir_alerta();
				reiniciar();
				
			} else {
				ativo = true;
				play();
			}
		} else {
			subfase.getAviso_setas().setVisivel(false);
		}

		// icone de sair
		if (((e.getX() >= 592 && e.getX() <= 620)) && ((e.getY() >= 10 && e.getY() <= 39))) {
			subfase.getOpcoes_sair().setVisivel(true);
		} else {
			subfase.getOpcoes_sair().setVisivel(false);
		}
		//opcao de menu
		if (((e.getX() >= 345 && e.getX() <= 471)) && ((e.getY() >= 116 && e.getY() <= 157))) {
			mudarPanels(menu, subfase);
		}
		//opcao sair
		if (((e.getX() >= 345 && e.getX() <= 471)) && ((e.getY() >= 178 && e.getY() <= 216))) {
			System.exit(0);
		}
		atualizarTela();
	}

}
