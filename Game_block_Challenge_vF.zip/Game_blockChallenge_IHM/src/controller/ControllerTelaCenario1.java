package controller;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import view.Cenario1CasteloAzul;
import view.Cenario1CasteloNeve;
import view.Cenario1CasteloVerde;
import view.Cenario1CasteloVermelho;
import view.TelaCenario01Principal;
import view.TelaControle;
import view.TelaFase02;
import view.Tela_menu;

public class ControllerTelaCenario1 extends KeyAdapter implements MouseListener {
	TelaControle telaControle;
	TelaCenario01Principal cenario1;
	TelaFase02 fase02;
	Cenario1CasteloVerde verde;
	Cenario1CasteloVermelho vermelho;
	Cenario1CasteloAzul azul;
	Cenario1CasteloNeve neve;
	int up, down, left, right;
	ControllerCen1CasteloVerd controllVerde;
	Tela_menu menu;

	public ControllerTelaCenario1(TelaControle telaControle) {
		this.telaControle = telaControle;
		this.cenario1 = telaControle.getCenario1();
		this.verde = telaControle.getVerde();
		this.vermelho = telaControle.getVermelho();
		this.azul = telaControle.getAzul();
		this.neve = telaControle.getNeve();
		this.fase02 = telaControle.getFase02();
		this.menu = telaControle.getMenu();

		telaControle.setVisible(true);
		control();

	}

	public void control() {
		cenario1.addKeyListener(this);
		cenario1.addMouseListener(this);
		cenario1.requestFocus();
	}

	public void atualizarTela() {

		cenario1.getTela().getGraphics().drawImage(cenario1.getFundo().getCamada(), 0, 0, null);
		cenario1.getTela().getGraphics().drawImage(cenario1.getCasteloVerd().getCamada(), 0, 0, null);
		cenario1.getTela().getGraphics().drawImage(cenario1.getCasteloVerm().getCamada(), 0, 0, null);
		cenario1.getTela().getGraphics().drawImage(cenario1.getCasteloAzul().getCamada(), 0, 0, null);
		cenario1.getTela().getGraphics().drawImage(cenario1.getCasteloNeve().getCamada(), 0, 0, null);
		cenario1.getTela().getGraphics().drawImage(cenario1.getCamColor1().getCamada(), 0, 0, null);

		cenario1.getTela().getGraphics().drawImage(cenario1.getCamIncolor2().getCamada(), 0, 0, null);
		cenario1.getTela().getGraphics().drawImage(cenario1.getCamIncolor3().getCamada(), 0, 0, null);
		cenario1.getTela().getGraphics().drawImage(cenario1.getCamIncolor4().getCamada(), 0, 0, null);

		if (!verde.getSeta().isVisivel() && cenario1.getCamColor2().isVisivel()) {
			cenario1.getTela().getGraphics().drawImage(cenario1.getCamColor2().getCamada(), 0, 0, null);
		}

		if (!vermelho.getSeta().isVisivel() && cenario1.getCamColor3().isVisivel()) {
			cenario1.getTela().getGraphics().drawImage(cenario1.getCamColor3().getCamada(), 0, 0, null);
		}

		if (!azul.getSeta().isVisivel() && cenario1.getCamColor4().isVisivel()) {
			cenario1.getTela().getGraphics().drawImage(cenario1.getCamColor4().getCamada(), 0, 0, null);
		}

		if (cenario1.getEfeitoBlock().isVisivel()) {
			cenario1.getTela().getGraphics().drawImage(cenario1.getEfeitoBlock().getImageObjeto(),
					cenario1.getEfeitoBlock().getPosX(), cenario1.getEfeitoBlock().getPosY(), null);

		}

		if (!neve.getSeta().isVisivel() && cenario1.getCaminhoColorCompleto().isVisivel()) {
			cenario1.getTela().getGraphics().drawImage(cenario1.getCaminhoColorCompleto().getCamada(), 0, 0, null);
			
		}

		cenario1.getTela().getGraphics().drawImage(
				cenario1.getPersonagem().getSprites()[cenario1.getPersonagem().getAparecia()],
				cenario1.getPersonagem().getPosX(), cenario1.getPersonagem().getPosY(), null);

		cenario1.getTela().getGraphics().drawImage(cenario1.getBotaoExit().getImageObjeto(),
				cenario1.getBotaoExit().getPosX(), cenario1.getBotaoExit().getPosY(), null);

		if (cenario1.getOpcoes_sair().isVisivel()) {
			cenario1.getTela().getGraphics().drawImage(cenario1.getOpcoes_sair().getImageObjeto(),
					cenario1.getOpcoes_sair().getPosX(), cenario1.getOpcoes_sair().getPosY(), null);
		}

		// evitar pisca pisca: condensa em um unico graphcs
		Graphics2D graphics2d = (Graphics2D) cenario1.getGraphics();
		graphics2d.drawImage(cenario1.getTela(), 0, 0, null);

		colisaoCastelos();
		
	}

	public void mudarPanels(JPanel panel1, JPanel panel2) {
		panel1.setVisible(true);
		panel1.requestFocus();
		panel2.setVisible(false);
		
	
	}

	public boolean colisaoCamIncolor() {
		Rectangle personagem = cenario1.getPersonagem().getBounds();
		List<Rectangle> cam2 = TelaCenario01Principal.retangulosColisaoCamIncolor2;
		List<Rectangle> cam3 = TelaCenario01Principal.retangulosColisaoCamIncolor3;
		List<Rectangle> cam4 = TelaCenario01Principal.retangulosColisaoCamIncolor4;

		if (cenario1.getCamIncolor2().isBloqueado()) {
			for (Rectangle caminho2 : cam2) {
				if (caminho2.intersects(personagem)) {
					return true;
				}
			}
		}
		if (cenario1.getCamIncolor3().isBloqueado()) {
			for (Rectangle caminho3 : cam3) {
				if (caminho3.intersects(personagem)) {
					return true;
				}
			}
		}
		if (cenario1.getCamIncolor4().isBloqueado()) {
			for (Rectangle caminho4 : cam4) {
				if (caminho4.intersects(personagem)) {
					return true;
				}
			}
		}

		return false;
	}

	public boolean colisaoCastelos() {
		Rectangle personagem = cenario1.getPersonagem().getBounds();
		List<Rectangle> casteloVerd = TelaCenario01Principal.retangulosColisaoCasteloVerde;
		List<Rectangle> casteloVerm = TelaCenario01Principal.retangulosColisaoCasteloVerm;
		List<Rectangle> casteloAzul = TelaCenario01Principal.retangulosColisaoCasteloAzul;
		List<Rectangle> casteloNeve = TelaCenario01Principal.retangulosColisaoCasteloNeve;

		for (Rectangle rectangle : casteloVerd) {
			if (rectangle.intersects(personagem)) {
				mudarPanels(verde, cenario1);
				verde.getPersonagem().setAparecia(0);
			}
		}
		for (Rectangle rectangle : casteloVerm) {
			if (rectangle.intersects(personagem)) {
				mudarPanels(vermelho, cenario1);
				vermelho.getPersonagem().setAparecia(0);
			}
		}
		for (Rectangle rectangle : casteloAzul) {
			if (rectangle.intersects(personagem)) {
				mudarPanels(azul, cenario1);
				azul.getPersonagem().setAparecia(0);
			}
		}
		for (Rectangle rectangle : casteloNeve) {
			if (rectangle.intersects(personagem)) {
				mudarPanels(neve, cenario1);
				neve.getPersonagem().setAparecia(0);
			}

		}
		return false;

	}

	public boolean colisaoFundo() {
		List<Rectangle> fundo = TelaCenario01Principal.retangulosColisaoFundo;
		Rectangle personagem = cenario1.getPersonagem().getBounds();

		for (Rectangle rectangle : fundo) {
			if (rectangle.intersects(personagem)) {
				return true;
			}
		}
		return false;
	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
			String[] options = { "Sim", "N�o" };
			int respostas = JOptionPane.showOptionDialog(null, "Deseja encerrar o game?", "", JOptionPane.YES_OPTION,
					JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
			if (respostas == JOptionPane.YES_OPTION) {
				System.exit(0);
			}

		}

		if (e.getKeyCode() == KeyEvent.VK_UP) {
			if (!colisaoFundo() && !colisaoCastelos() && !colisaoCamIncolor()) {
				cenario1.getPersonagem()
						.setPosY(cenario1.getPersonagem().getPosY() - cenario1.getPersonagem().getVelocidade());

			}

			switch (up) {
			case 0:
				cenario1.getPersonagem().setAparecia(3);
				break;
			case 1:
				cenario1.getPersonagem().setAparecia(7);
				break;
			case 2:
				cenario1.getPersonagem().setAparecia(11);
				break;
			case 3:
				cenario1.getPersonagem().setAparecia(15);
				break;

			}
			if (up == 3)
				up = 0;
			else
				up++;

			atualizarTela();

		}
		if (e.getKeyCode() == KeyEvent.VK_DOWN) {

			if (!colisaoFundo() && !colisaoCastelos() && !colisaoCamIncolor()) {
				cenario1.getPersonagem()
						.setPosY(cenario1.getPersonagem().getPosY() + cenario1.getPersonagem().getVelocidade());
			}
			switch (down) {
			case 0:
				cenario1.getPersonagem().setAparecia(0);
				break;
			case 1:
				cenario1.getPersonagem().setAparecia(4);
				break;
			case 2:
				cenario1.getPersonagem().setAparecia(8);
				break;
			case 3:
				cenario1.getPersonagem().setAparecia(12);
				break;
			}

			if (down == 3)
				down = 0;
			else
				down++;

			atualizarTela();

		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {

			if (!colisaoFundo() && !colisaoCastelos() && !colisaoCamIncolor()) {

				cenario1.getPersonagem()
						.setPosX(cenario1.getPersonagem().getPosX() - cenario1.getPersonagem().getVelocidade());
			}

			switch (left) {
			case 0:
				cenario1.getPersonagem().setAparecia(1);
				break;
			case 1:
				cenario1.getPersonagem().setAparecia(5);
				break;
			case 2:
				cenario1.getPersonagem().setAparecia(9);
				break;
			case 3:
				cenario1.getPersonagem().setAparecia(13);
				break;

			}

			if (left == 3)
				left = 0;
			else
				left++;

			atualizarTela();

		}
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {

			if (!colisaoFundo() && !colisaoCastelos() && !colisaoCamIncolor()) {
				cenario1.getPersonagem()
						.setPosX(cenario1.getPersonagem().getPosX() + cenario1.getPersonagem().getVelocidade());
			}
			switch (right) {
			case 0:
				cenario1.getPersonagem().setAparecia(2);
				break;
			case 1:
				cenario1.getPersonagem().setAparecia(6);
				break;
			case 2:
				cenario1.getPersonagem().setAparecia(10);
				break;
			case 3:
				cenario1.getPersonagem().setAparecia(14);
				break;

			}

			if (right == 3)
				right = 0;
			else
				right++;

			atualizarTela();
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_UP) {
			if (colisaoFundo() || colisaoCamIncolor()) {
				cenario1.getPersonagem()
						.setPosY(cenario1.getPersonagem().getPosY() + cenario1.getPersonagem().getVelocidade());
			}
		}

		if (e.getKeyCode() == KeyEvent.VK_DOWN) {
			if (colisaoFundo() || colisaoCamIncolor()) {
				cenario1.getPersonagem()
						.setPosY(cenario1.getPersonagem().getPosY() - cenario1.getPersonagem().getVelocidade());
			}

		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			if (colisaoFundo() || colisaoCamIncolor()) {
				cenario1.getPersonagem()
						.setPosX(cenario1.getPersonagem().getPosX() + cenario1.getPersonagem().getVelocidade());
			}

		}
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			if (colisaoFundo() || colisaoCamIncolor()) {
				cenario1.getPersonagem()
						.setPosX(cenario1.getPersonagem().getPosX() - cenario1.getPersonagem().getVelocidade());
			}

		}

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (((e.getX() >= 592 && e.getX() <= 620)) && ((e.getY() >= 10 && e.getY() <= 39))) {
			cenario1.getOpcoes_sair().setVisivel(true);

		} else {
			cenario1.getOpcoes_sair().setVisivel(false);
		}

		if (((e.getX() >= 345 && e.getX() <= 471)) && ((e.getY() >= 116 && e.getY() <= 157))) {
			mudarPanels(menu, cenario1);
			cenario1.getPersonagem().setPosX(283);
		}
		if (((e.getX() >= 345 && e.getX() <= 471)) && ((e.getY() >= 178 && e.getY() <= 216))) {
			System.exit(0);
		}

		atualizarTela();
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}
}
