package controller;

import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import view.Cenario1CasteloNeve;
import view.Cenario1CasteloVerde;
import view.Cenario1CasteloVermelho;
import view.SubFase2;
import view.TelaCenario01Principal;
import view.TelaControle;
import view.Tela_menu;

public class ControllerCen1CasteloVerm extends KeyAdapter implements MouseListener {
	TelaControle telaControle;
	Cenario1CasteloVermelho vermelho;
	TelaCenario01Principal cenario1;
	SubFase2 subfase;
	Tela_menu menu;

	int up, down, left, right;
	int W, S, A, D;
	boolean running = true;
	Thread t;

	public ControllerCen1CasteloVerm(TelaControle controle) {
		this.telaControle = controle;
		this.vermelho = telaControle.getVermelho();
		this.cenario1 = telaControle.getCenario1();
		this.subfase = telaControle.getSubfase();
		this.menu = telaControle.getMenu();

		telaControle.setVisible(true);
		control();

	}

	public void control() {
		vermelho.addKeyListener(this);
		vermelho.addMouseListener(this);
		vermelho.requestFocus();
	}

	public void atualizarTela() {
		vermelho.getTela().getGraphics().drawImage(vermelho.getFundo().getCamada(), 0, 0, null);
		vermelho.getTela().getGraphics().drawImage(vermelho.getColisao().getCamada(), 0, 0, null);
		vermelho.getTela().getGraphics().drawImage(vermelho.getPedras().getCamada(), 0, 0, null);
		vermelho.getTela().getGraphics().drawImage(vermelho.getCastelo().getCamada(), 0, 0, null);

		vermelho.getTela().getGraphics().drawImage(
				vermelho.getPersonagem().getSprites()[vermelho.getPersonagem().getAparecia()],
				vermelho.getPersonagem().getPosX(), vermelho.getPersonagem().getPosY(), null);

		vermelho.getTela().getGraphics().drawImage(vermelho.getPinheiro().getCamada(), 0, 0, null);

		if (vermelho.getSeta().isVisivel()) {
			vermelho.getTela().getGraphics().drawImage(vermelho.getSeta().getImageObjeto(),
					vermelho.getSeta().getPosX(), vermelho.getSeta().getPosY(), null);
		}

		vermelho.getTela().getGraphics().drawImage(vermelho.getBotaoExit().getImageObjeto(),
				vermelho.getBotaoExit().getPosX(), vermelho.getBotaoExit().getPosY(), null);

		if (vermelho.getOpcoes_sair().isVisivel()) {
			vermelho.getTela().getGraphics().drawImage(vermelho.getOpcoes_sair().getImageObjeto(),
					vermelho.getOpcoes_sair().getPosX(), vermelho.getOpcoes_sair().getPosY(), null);
		}

		// evitar pisca pisca: condensa em um unico graphcs
		Graphics2D graphics2d = (Graphics2D) vermelho.getGraphics();
		graphics2d.drawImage(vermelho.getTela(), 0, 0, null);

		destravaCaminho();

	}

	public void setandoDirecoes() {
		subfase.getPersonagem().setPosX(315);
		subfase.getPersonagem().setPosY(215);
		subfase.getPersonagem().setAparecia(4);

		subfase.getCamCima().setVisivel(true);
		subfase.getPortaCima().setVisivel(true);
		subfase.getSetaCima().setVisivel(true);

		subfase.getCamDireita().setVisivel(false);
		subfase.getPortaDireita().setVisivel(false);
		subfase.getSetaDireita().setVisivel(false);
	}

	public boolean destravaCaminho() {
		Rectangle personagem = vermelho.getPersonagem().getBounds();
		Rectangle seta = vermelho.getSeta().getBounds();

		if (personagem.intersects(seta)) {
			vermelho.getSeta().setVisivel(false);
			cenario1.getCamIncolor3().setBloqueado(false);
			cenario1.getCamColor3().setVisivel(true);
			setandoDirecoes();

			mudarPanels(subfase, vermelho);

//			System.out.println("insters");
			return true;

		}
		return false;
	}

	public boolean colisaoCasteloVerm() {
		List<Rectangle> castelo = Cenario1CasteloVermelho.retangulosColisaoCastelo;
		Rectangle personagem = vermelho.getPersonagem().getBounds();

		for (Rectangle rectangle : castelo) {
			if (rectangle.intersects(personagem)) {
				vermelho.getPersonagem().setPosX(557);
				vermelho.getPersonagem().setPosY(80);

			}

		}
		return false;

	}

	public boolean colisaoTronco_e_lateral() {
		List<Rectangle> colisoes = Cenario1CasteloVermelho.retangulosColisaoTronco;
		Rectangle personagem = vermelho.getPersonagem().getBounds();

		for (Rectangle rectangle : colisoes) {
			if (rectangle.intersects(personagem)) {
				return true;
			}
		}
		return false;

	}

	public void mudarPanels(JPanel panel1, JPanel panel2) {
		panel1.setVisible(true);
		panel2.setVisible(false);
		panel1.requestFocus();

	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
			String[] options = { "Sim", "N�o" };
			int respostas = JOptionPane.showOptionDialog(null, "Deseja encerrar o game?", "", JOptionPane.YES_OPTION,
					JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
			if (respostas == JOptionPane.YES_OPTION) {
				System.exit(0);
			}

		}

		if (e.getKeyCode() == KeyEvent.VK_UP) {
			if (!colisaoTronco_e_lateral() && !colisaoCasteloVerm()) {

				vermelho.getPersonagem()
						.setPosY(vermelho.getPersonagem().getPosY() - vermelho.getPersonagem().getVelocidade());
			}

			switch (W) {
			case 0:
				vermelho.getPersonagem().setAparecia(3);
				break;
			case 1:
				vermelho.getPersonagem().setAparecia(7);
				break;
			case 2:
				vermelho.getPersonagem().setAparecia(11);
				break;
			case 3:
				vermelho.getPersonagem().setAparecia(15);
				break;

			}
			if (W == 3)
				W = 0;
			else
				W++;

			atualizarTela();

		}
		if (e.getKeyCode() == KeyEvent.VK_DOWN) {
			if (!colisaoTronco_e_lateral() && !colisaoCasteloVerm()) {
				vermelho.getPersonagem()
						.setPosY(vermelho.getPersonagem().getPosY() + vermelho.getPersonagem().getVelocidade());
			}
			switch (S) {
			case 0:
				vermelho.getPersonagem().setAparecia(0);
				break;
			case 1:
				vermelho.getPersonagem().setAparecia(4);
				break;
			case 2:
				vermelho.getPersonagem().setAparecia(8);
				break;
			case 3:
				vermelho.getPersonagem().setAparecia(12);
				break;
			}

			if (S == 3)
				S = 0;
			else
				S++;

			atualizarTela();

		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			if (!colisaoTronco_e_lateral() && !colisaoCasteloVerm()) {
				vermelho.getPersonagem()
						.setPosX(vermelho.getPersonagem().getPosX() - vermelho.getPersonagem().getVelocidade());
			}
			switch (A) {
			case 0:
				vermelho.getPersonagem().setAparecia(1);
				break;
			case 1:
				vermelho.getPersonagem().setAparecia(5);
				break;
			case 2:
				vermelho.getPersonagem().setAparecia(9);
				break;
			case 3:
				vermelho.getPersonagem().setAparecia(13);
				break;

			}

			if (A == 3)
				A = 0;
			else
				A++;

			atualizarTela();

		}
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			if (!colisaoTronco_e_lateral() && !colisaoCasteloVerm()) {
				vermelho.getPersonagem()
						.setPosX(vermelho.getPersonagem().getPosX() + vermelho.getPersonagem().getVelocidade());
			}
			switch (D) {
			case 0:
				vermelho.getPersonagem().setAparecia(2);
				break;
			case 1:
				vermelho.getPersonagem().setAparecia(6);
				break;
			case 2:
				vermelho.getPersonagem().setAparecia(10);
				break;
			case 3:
				vermelho.getPersonagem().setAparecia(14);
				break;

			}

			if (D == 3)
				D = 0;
			else
				D++;

			atualizarTela();
		}
	}

	@Override
	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_UP) {
			if (colisaoTronco_e_lateral())
				vermelho.getPersonagem()
						.setPosY(vermelho.getPersonagem().getPosY() + vermelho.getPersonagem().getVelocidade());
		}
		if (e.getKeyCode() == KeyEvent.VK_DOWN) {
			if (colisaoTronco_e_lateral())
				vermelho.getPersonagem()
						.setPosY(vermelho.getPersonagem().getPosY() - vermelho.getPersonagem().getVelocidade());
		}
		if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			if (colisaoTronco_e_lateral())
				vermelho.getPersonagem()
						.setPosX(vermelho.getPersonagem().getPosX() + vermelho.getPersonagem().getVelocidade());

		}
		if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			if (colisaoTronco_e_lateral())
				vermelho.getPersonagem()
						.setPosX(vermelho.getPersonagem().getPosX() - vermelho.getPersonagem().getVelocidade());

		}

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (((e.getX() >= 611 && e.getX() <= 635)) && ((e.getY() >= 7 && e.getY() <= 33))) {
			vermelho.getOpcoes_sair().setVisivel(true);

		} else {
			vermelho.getOpcoes_sair().setVisivel(false);
		}

		if (((e.getX() >= 345 && e.getX() <= 471)) && ((e.getY() >= 116 && e.getY() <= 157))) {
			mudarPanels(menu, vermelho);

		}
		if (((e.getX() >= 345 && e.getX() <= 471)) && ((e.getY() >= 178 && e.getY() <= 216))) {
			System.exit(0);
		}

		atualizarTela();

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}
}
