package controller;

import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;

import view.TelaCenario01Principal;
import view.TelaControle;
import view.Tela_menu;

public class ControllerMenu extends MouseAdapter {
	Tela_menu menu;
	TelaControle telaControle;
	TelaCenario01Principal cenario1;

	public ControllerMenu(TelaControle controle) {
		this.telaControle = controle;
		this.cenario1 = telaControle.getCenario1();
		this.menu = telaControle.getMenu();
		telaControle.setVisible(true);
		control();
	}

	public void control() {
		menu.addMouseListener(this);

	}

	public void mudarPanels(JPanel panel1, JPanel panel2) {
		panel1.setVisible(true);
		panel2.setVisible(false);
		panel1.requestFocus();

	}

	void atualizarTela() {
		if (menu.getMenu().isVisivel()) {
			menu.getTela().getGraphics().drawImage(menu.getMenu().getImageObjeto(), 0, 0, null);
		}

		if (menu.getHistoriaJogo().isVisivel()) {
			menu.getTela().getGraphics().drawImage(menu.getHistoriaJogo().getImageObjeto(), 0, 0, null);
		}

		if (menu.getAjuda1().isVisivel()) {
			menu.getTela().getGraphics().drawImage(menu.getAjuda1().getImageObjeto(), 0, 0, null);
		}

		if (menu.getAjuda2().isVisivel()) {
			menu.getTela().getGraphics().drawImage(menu.getAjuda2().getImageObjeto(), 0, 0, null);
		}

		Graphics2D graphics2d = (Graphics2D) menu.getGraphics();
		graphics2d.drawImage(menu.getTela(), 0, 0, null);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		System.out.println("x" + e.getX());
		System.out.println("y" + e.getY());

		// Seta
		if (((e.getX() >= 251 && e.getX() <= 380)) && ((e.getY() >= 177 && e.getY() <= 225))) {
			mudarPanels(cenario1, menu);
		}
		// botao ajuda
		if (((e.getX() >= 251 && e.getX() <= 380)) && ((e.getY() >= 248 && e.getY() <= 296))) {
			menu.getAjuda1().setVisivel(true);
		} // de ajuda1 para ajuda 2
		if (((e.getX() >= 489 && e.getX() <= 625)) && ((e.getY() >= 14 && e.getY() <= 44))) {
			menu.getAjuda1().setVisivel(false);
			menu.getAjuda2().setVisivel(true);

		}
		// voltar para ajuda01
		if (((e.getX() >= 170 && e.getX() <= 310)) && ((e.getY() >= 17 && e.getY() <= 49))) {
			menu.getAjuda1().setVisivel(true);
			menu.getAjuda2().setVisivel(false);
		}
		// fechar e ir para menu
		if (((e.getX() >= 324 && e.getX() <= 465)) && ((e.getY() >= 17 && e.getY() <= 49))) {
			menu.getAjuda2().setVisivel(false);
		}
		//historia
		if (((e.getX() >= 251 && e.getX() <= 380)) && ((e.getY() >= 316 && e.getY() <= 365))) {
			menu.getHistoriaJogo().setVisivel(true);
		}
		if (((e.getX() >= 219 && e.getX() <= 400)) && ((e.getY() >= 6 && e.getY() <= 34)) && menu.getHistoriaJogo().isVisivel()) {
			menu.getHistoriaJogo().setVisivel(false);
			menu.getAjuda1().setVisivel(false);
			menu.getAjuda2().setVisivel(false);
		}

		if (((e.getX() >= 251 && e.getX() <= 380)) && ((e.getY() >= 385 && e.getY() <= 434))) {
			System.exit(0);
		}
		atualizarTela();
	}

}
