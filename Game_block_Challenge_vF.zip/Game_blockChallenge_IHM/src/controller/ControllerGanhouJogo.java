package controller;

import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JPanel;

import view.TelaControle;
import view.TelaGanhouJogo;
import view.Tela_menu;

public class ControllerGanhouJogo extends MouseAdapter {
	TelaControle controle;
	TelaGanhouJogo ganhouJogo;
	Tela_menu menu;

	public ControllerGanhouJogo(TelaControle controle) {
		this.controle = controle;
		this.ganhouJogo = controle.getGanhouJogo();
		this.menu = controle.getMenu();

		controle.setVisible(true);
		controll();
	}

	public void controll() {
		ganhouJogo.addMouseListener(this);
	}

	public void atualizarTela() {
		ganhouJogo.getTela().getGraphics().drawImage(ganhouJogo.getGanhou_jogo().getImageObjeto(),
				ganhouJogo.getGanhou_jogo().getPosX(), ganhouJogo.getGanhou_jogo().getPosY(), null);

		ganhouJogo.getTela().getGraphics().drawImage(ganhouJogo.getBotaoExit2().getImageObjeto(),
				ganhouJogo.getBotaoExit2().getPosX(), ganhouJogo.getBotaoExit2().getPosY(), null);

		if (ganhouJogo.getOpcoes_sair().isVisivel()) {
			ganhouJogo.getTela().getGraphics().drawImage(ganhouJogo.getOpcoes_sair().getImageObjeto(),
					ganhouJogo.getOpcoes_sair().getPosX(), ganhouJogo.getOpcoes_sair().getPosY(), null);

		}

		Graphics2D graphics2d = (Graphics2D) ganhouJogo.getGraphics();
		graphics2d.drawImage(ganhouJogo.getTela(), 0, 0, null);
	}

	public void mudarPanels(JPanel panel1, JPanel panel2) {
		panel1.setVisible(true);
		panel2.setVisible(false);
		panel1.requestFocus();

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// icone de sair
		if (((e.getX() >= 592 && e.getX() <= 620)) && ((e.getY() >= 10 && e.getY() <= 39))) {
			ganhouJogo.getOpcoes_sair().setVisivel(true);
		} else {
			ganhouJogo.getOpcoes_sair().setVisivel(false);
		}
		// opcao de menu
		if (((e.getX() >= 345 && e.getX() <= 471)) && ((e.getY() >= 116 && e.getY() <= 157))) {
			mudarPanels(menu, ganhouJogo);
		}
		// opcao sair
		if (((e.getX() >= 345 && e.getX() <= 471)) && ((e.getY() >= 178 && e.getY() <= 216))) {
			System.exit(0);
		}
		atualizarTela();
	}

}
