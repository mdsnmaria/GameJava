package model;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

import view.TelaCenario01Principal;

public abstract class Sprite {// � atributo de personagem
	BufferedImage spriteSheet;
	Rectangle rectangle;
	int velX, velY;
	boolean isVisivel;
	int velocidade=5;
	
	private boolean movimento= true;
	private boolean esquerda;
	private boolean direita;
	private boolean cima;
	private boolean baixo;

	int larguraWidth, alturaHeight;
	int linhasRows, colunasColums;
	private int posX;// � atributo de personagem
	private int posY;
	BufferedImage[] sprites; // cada imagem vai ser recortada e colocada dentro desse vetor
	private int aparecia; // � atributo de personagem
	int moverX, moverY;

	public Sprite(String file, int aparencia, int colunasColums, int linhasRows, int posX, int posY, int larguraPers,
			int alturaPers) {
		// pode usar os codigos da liha 21 e 21, mas, tem que garantir que todos os
		// pixels sejam iguais, sendo assim nao precisaria receber por parametro a
		// largura e a altura
//		this.larguraWidth= spriteSheet.getWidth()/colunasColums;
//		this.alturaHeight= spriteSheet.getHeight()/linhasRows;
		//
		try {
			spriteSheet = ImageIO.read(getClass().getResourceAsStream(file));
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Imagem/sprite n�o encontrada!");
			System.exit(0);

		}

		this.larguraWidth = larguraPers;
		this.alturaHeight = alturaPers;
		this.linhasRows = linhasRows;
		this.colunasColums = colunasColums;

		this.posX = posX;
		this.posY = posY;
		this.setAparecia(aparecia);

		setSprites(new BufferedImage[colunasColums * linhasRows]);// as imagens s�o recortadas e armazenas nesse vetor//
																	// o tamanho do vetor sera a quantidade de elementos
																	// da coluna X a quantidade de elementos da linha
		for (int i = 0; i < colunasColums; i++) {
			for (int j = 0; j < linhasRows; j++) {
				// percorrendo a imagem por linha [0]= 0*0+0; [1]= 0*1+1; ...
				getSprites()[i * linhasRows + j] = spriteSheet.getSubimage(i * larguraWidth, j * alturaHeight,
						larguraWidth, alturaHeight);// inicialmente a imagem vai de 0,0 ate a largura e altura;
			}
		}
	}

	public abstract Rectangle getBounds();
		


	public BufferedImage[] getSprites() {
		return sprites;
	}

	public void setSprites(BufferedImage[] sprites) {
		this.sprites = sprites;
	}

	public int getAparecia() {
		return aparecia;
	}

	public void setAparecia(int aparecia) {
		this.aparecia = aparecia;
	}

	public int getPosX() {
		return posX;
	}

	public void setPosX(int posX) {
		this.posX = posX;
	}

	public int getPosY() {
		return posY;
	}

	public void setPosY(int posY) {

		this.posY = posY;

	}

	public int getLarguraWidth() {
		return larguraWidth;
	}

	public void setLarguraWidth(int larguraWidth) {
		this.larguraWidth = larguraWidth;
	}

	public int getAlturaHeight() {
		return alturaHeight;
	}

	public void setAlturaHeight(int alturaHeight) {
		this.alturaHeight = alturaHeight;
	}

	public boolean isVisivel() {
		return isVisivel;
	}

	public int getVelocidade() {
		return velocidade;
	}

	public void setVelocidade(int velocidade) {
		this.velocidade = velocidade;
	}

	public void setVisivel(boolean isVisivel) {
		this.isVisivel = isVisivel;
	}

	public boolean isEsquerda() {
		return esquerda;
	}

	public void setEsquerda(boolean esquerda) {
		this.esquerda = esquerda;
	}

	public boolean isDireita() {
		return direita;
	}

	public void setDireita(boolean direita) {
		this.direita = direita;
	}

	public boolean isCima() {
		return cima;
	}

	public void setCima(boolean cima) {
		this.cima = cima;
	}

	public boolean isBaixo() {
		return baixo;
	}

	public void setBaixo(boolean baixo) {
		this.baixo = baixo;
	}

	public BufferedImage getSpriteSheet() {
		return spriteSheet;
	}

	public Rectangle getRectangle() {
		return rectangle;
	}

	public int getVelX() {
		return velX;
	}

	public int getVelY() {
		return velY;
	}

	public boolean isMovimento() {
		return movimento;
	}

	public int getLinhasRows() {
		return linhasRows;
	}

	public int getColunasColums() {
		return colunasColums;
	}

	public int getMoverX() {
		return moverX;
	}

	public int getMoverY() {
		return moverY;
	}
}
