package model;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;

public class TileMap {

	private int mapa[][];
	private BufferedImage camada;
	private BufferedImage tiledSet;
	private int mapaLarguraWidth;
	private int mapaAlturaHeight;
	private int tiledSetLarguraWidth;
	private int tiledSetAlturaHeight;
	private Rectangle rectangle;
	private boolean isBloqueado;
	private boolean isVisivel;

	public TileMap(String img, int mapaLarguraWidth, int mapaAlturaHeight, int tiledSetLarguraWidth,
			int tiledSetAlturaHeight, String arquivo, boolean status) {
		this.mapaLarguraWidth = mapaLarguraWidth;
		this.mapaAlturaHeight = mapaAlturaHeight;
		this.tiledSetLarguraWidth = tiledSetLarguraWidth;
		this.tiledSetAlturaHeight = tiledSetAlturaHeight;
		isBloqueado = true;
		isVisivel = status;

		// rectangle = new Rectangle(tiledSetLarguraWidth, tiledSetAlturaHeight);

		try {
			mapa = new int[mapaLarguraWidth][mapaAlturaHeight];
			mapa = carregarMatriz(mapa, arquivo);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "Erro de execu��o! Erro  no txt "+ arquivo);
			System.exit(0);
		}

		try {
			 tiledSet=ImageIO.read(getClass().getResourceAsStream(img));

		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Erro de execu��o! na img " + img);
			System.exit(0);
		}
	}

	public int[][] carregarMatriz(int[][] matriz, String arquivo) {// pega qualquer arquivo e converte em matriz
		ArrayList<String> linhasMatrizCamadas = new ArrayList<String>();
		InputStream is = getClass().getResourceAsStream(arquivo);

		// br � o arquivo que cont�m os dados da matriz do cenario
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
		

		String linha = "";
		StringTokenizer token;

		try {
			while ((linha = br.readLine()) != null) {// se o conteudo da linha for diferente de null, adiciona ao
														// arrayList
				linhasMatrizCamadas.add(linha);

			}
			int j = 0;
			for (int i = 0; i < linhasMatrizCamadas.size(); i++) {
				token = new StringTokenizer(linhasMatrizCamadas.get(i), ",");

				while (token.hasMoreElements()) {
					matriz[i][j] = Integer.parseInt(token.nextToken());// pega cada elemento do token e vai dando carga
																		// dentro da matriz
					j++;
				}
				j = 0; // toda vez que acabar as linhas o j volta a ser zero
			}
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Erro de execu��o!");
			System.exit(0);

		}
		return matriz;
	}

	public void montarMapa(int largura, int altura) {// logica para extrair cada elemento da camada e armazenar em uma
														// imagem
		camada = new BufferedImage(largura, altura, BufferedImage.TYPE_4BYTE_ABGR);// BufferedImage.TYPE_4BYTE_ABGR_PRE
																					// area de memoria para armazenar a
																					// imagem
		camada.createGraphics();

		int tile;
		int tiledLinhasRows;
		int tiledColunaColums;
		int totalColunaTiled = tiledSet.getWidth() / tiledSetLarguraWidth;
		// int totalColunaTiled = tiledSet.getWidth();

		for (int i = 0; i < mapaLarguraWidth; i++) {
			for (int j = 0; j < mapaAlturaHeight; j++) {
				tile = (mapa[i][j] != 0) ? (mapa[i][j] - 1) : 0;// if ternario
				tiledLinhasRows = (tile / (totalColunaTiled)) | 0;
				tiledColunaColums = (tile % (totalColunaTiled)) | 0;
				camada.getGraphics().drawImage(tiledSet, (j * tiledSetAlturaHeight), (i * tiledSetLarguraWidth),
						(j * tiledSetAlturaHeight) + tiledSetAlturaHeight,
						(i * tiledSetLarguraWidth) + tiledSetLarguraWidth, (tiledColunaColums * tiledSetAlturaHeight),
						(tiledLinhasRows * tiledSetLarguraWidth),
						(tiledColunaColums * tiledSetAlturaHeight) + tiledSetAlturaHeight,
						(tiledLinhasRows * tiledSetLarguraWidth) + tiledSetLarguraWidth, null);

			}

		}
	}

	public List<Rectangle> montarColisao() {
		List<Rectangle> tmp = new ArrayList<Rectangle>();

		for (int i = 0; i < mapaLarguraWidth; i++) {
			for (int j = 0; j < mapaAlturaHeight; j++) {
				if (mapa[i][j] != 0) {
					tmp.add(new Rectangle((j * tiledSetAlturaHeight), (i * tiledSetLarguraWidth), tiledSetLarguraWidth,
							tiledSetAlturaHeight));

				}
			}
		}
		return tmp;
	}

	public List<Rectangle> montarColisaoFundo() {
		List<Rectangle> tmp = new ArrayList<Rectangle>();
		for (int i = 0; i < mapaLarguraWidth; i++) {
			for (int j = 0; j < mapaAlturaHeight; j++) {
				if (mapa[i][j] != 814) {
					tmp.add(new Rectangle((j * tiledSetAlturaHeight), (i * tiledSetLarguraWidth), tiledSetLarguraWidth,
							tiledSetAlturaHeight));
				}
			}
		}
		return tmp;
	}

	public List<Rectangle> montarColisaoIncolorCam2() {

		List<Rectangle> tmp = new ArrayList<Rectangle>();
		if (isBloqueado) {
			for (int i = 0; i < mapaLarguraWidth; i++) {
				for (int j = 0; j < mapaAlturaHeight; j++) {
					if (mapa[i][j] == 488) {
						tmp.add(new Rectangle((j * tiledSetAlturaHeight), (i * tiledSetLarguraWidth),
								tiledSetLarguraWidth, tiledSetAlturaHeight));

					}
				}
			}

		}
		return tmp;
	}
	
	public List<Rectangle> montarColisaoIncolorCam3() {

		List<Rectangle> tmp = new ArrayList<Rectangle>();
		if (isBloqueado) {
			for (int i = 0; i < mapaLarguraWidth; i++) {
				for (int j = 0; j < mapaAlturaHeight; j++) {
					if (mapa[i][j] == 489) {
						tmp.add(new Rectangle((j * tiledSetAlturaHeight), (i * tiledSetLarguraWidth),
								tiledSetLarguraWidth, tiledSetAlturaHeight));

					}
				}
			}

		}
		return tmp;
	}
	
	public List<Rectangle> montarColisaoIncolorCam4() {

		List<Rectangle> tmp = new ArrayList<Rectangle>();
		if (isBloqueado) {
			for (int i = 0; i < mapaLarguraWidth; i++) {
				for (int j = 0; j < mapaAlturaHeight; j++) {
					if (mapa[i][j] == 483) {
						tmp.add(new Rectangle((j * tiledSetAlturaHeight), (i * tiledSetLarguraWidth),
								tiledSetLarguraWidth, tiledSetAlturaHeight));

					}
				}
			}

		}
		return tmp;
	}

	public List<Rectangle> montarColisaoCenarioVerde() {
		List<Rectangle> tmp = new ArrayList<Rectangle>();
		for (int i = 0; i < mapaLarguraWidth; i++) {
			for (int j = 0; j < mapaAlturaHeight; j++) {
				if (mapa[i][j] == 92 || mapa[i][j] == 26 || mapa[i][j] == 4) {
					tmp.add(new Rectangle((j * tiledSetAlturaHeight), (i * tiledSetLarguraWidth), tiledSetLarguraWidth,
							tiledSetAlturaHeight));

				}
			}
		}
		return tmp;
	}

	public List<Rectangle> montarColisaoCenarioVermelho() {
		List<Rectangle> tmp = new ArrayList<Rectangle>();
		for (int i = 0; i < mapaLarguraWidth; i++) {
			for (int j = 0; j < mapaAlturaHeight; j++) {
				if (mapa[i][j] == 174 || mapa[i][j] == 26 || mapa[i][j] == 4) {
					tmp.add(new Rectangle((j * tiledSetAlturaHeight), (i * tiledSetLarguraWidth), tiledSetLarguraWidth,
							tiledSetAlturaHeight));

				}
			}
		}
		return tmp;
	}

	public List<Rectangle> montarColisaoCenarioAzul() {
		List<Rectangle> tmp = new ArrayList<Rectangle>();
		for (int i = 0; i < mapaLarguraWidth; i++) {
			for (int j = 0; j < mapaAlturaHeight; j++) {
				if (mapa[i][j] == 72 || mapa[i][j] == 26 || mapa[i][j] == 4) {
					tmp.add(new Rectangle((j * tiledSetAlturaHeight), (i * tiledSetLarguraWidth), tiledSetLarguraWidth,
							tiledSetAlturaHeight));

				}
			}
		}
		return tmp;
	}

	public List<Rectangle> montarColisaoCenarioNeve() {
		List<Rectangle> tmp = new ArrayList<Rectangle>();
		for (int i = 0; i < mapaLarguraWidth; i++) {
			for (int j = 0; j < mapaAlturaHeight; j++) {
				if (mapa[i][j] == 4 || mapa[i][j] == 5 || mapa[i][j] == 6 || mapa[i][j] == 11 || mapa[i][j] == 18
						|| mapa[i][j] == 19 || mapa[i][j] == 20 || mapa[i][j] == 13) {
					tmp.add(new Rectangle((j * tiledSetAlturaHeight), (i * tiledSetLarguraWidth), tiledSetLarguraWidth,
							tiledSetAlturaHeight));

				}
			}
		}
		return tmp;
	}

	public List<Rectangle> montarColisaoTroncoNeve() {
		List<Rectangle> tmp = new ArrayList<Rectangle>();
		for (int i = 0; i < mapaLarguraWidth; i++) {
			for (int j = 0; j < mapaAlturaHeight; j++) {
				if (mapa[i][j] == 169 || mapa[i][j] == 170) {
					tmp.add(new Rectangle((j * tiledSetAlturaHeight), (i * tiledSetLarguraWidth), tiledSetLarguraWidth,
							tiledSetAlturaHeight));

				}
			}
		}
		return tmp;
	}
	
	public List<Rectangle> montarColisaoPortaSub2() {
		List<Rectangle> tmp = new ArrayList<Rectangle>();
		for (int i = 0; i < mapaLarguraWidth; i++) {
			for (int j = 0; j < mapaAlturaHeight; j++) {
				if (mapa[i][j] == 95) {
					tmp.add(new Rectangle((j * tiledSetAlturaHeight), (i * tiledSetLarguraWidth), tiledSetLarguraWidth,
							tiledSetAlturaHeight));

				}
			}
		}
		return tmp;
	}

	public int getMapaLarguraWidth() {
		return mapaLarguraWidth;
	}

	public BufferedImage getCamada() {
		return camada;
	}

	public void setCamada(BufferedImage camada) {
		this.camada = camada;
	}

	public void setMapaLarguraWidth(int mapaLarguraWidth) {
		this.mapaLarguraWidth = mapaLarguraWidth;
	}

	public int getMapaAlturaHeight() {
		return mapaAlturaHeight;
	}

	public void setMapaAlturaHeight(int mapaAlturaHeight) {
		this.mapaAlturaHeight = mapaAlturaHeight;
	}

	public int getTiledSetLarguraWidth() {
		return tiledSetLarguraWidth;
	}

	public void setTiledSetLarguraWidth(int tiledSetLarguraWidth) {
		this.tiledSetLarguraWidth = tiledSetLarguraWidth;
	}

	public int getTiledSetAlturaHeight() {
		return tiledSetAlturaHeight;
	}

	public void setTiledSetAlturaHeight(int tiledSetAlturaHeight) {
		this.tiledSetAlturaHeight = tiledSetAlturaHeight;
	}

	public BufferedImage getTiledSet() {
		return tiledSet;
	}

	public void setTiledSet(BufferedImage tiledSet) {
		this.tiledSet = tiledSet;
	}

	public boolean isBloqueado() {
		return isBloqueado;
	}

	public void setBloqueado(boolean isBloqueado) {
		this.isBloqueado = isBloqueado;
	}

	public boolean isVisivel() {
		return isVisivel;
	}

	public void setVisivel(boolean isVisivel) {
		this.isVisivel = isVisivel;
	}

}
