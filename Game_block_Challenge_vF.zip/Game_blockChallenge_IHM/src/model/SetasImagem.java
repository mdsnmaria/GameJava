package model;

import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public abstract class SetasImagem {
//	ImageIcon imageObjeto;
	int posX, posY;
	int width, height;
	private BufferedImage imageObjeto;
	
	
	public SetasImagem(String caminho, int posX, int posY, int width, int height) {
		
		try {
			imageObjeto =ImageIO.read(getClass().getResourceAsStream(caminho));
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null, "Erro de execu��o! na img " + caminho);
			e.printStackTrace();
		}
//		imageObjeto = new  ImageIcon(caminho);
		this.posX = posX;
		this.posY = posY;
		this.width = width;
		this.height = height;
	}
	
	public Rectangle getBounds() {
		return new Rectangle(posX, posY, width - 10, height - 10);
	}

//	public ImageIcon getImageObjeto() {
//		return imageObjeto;
//	}
//
//	public void setImageObjeto(ImageIcon imageObjeto) {
//		this.imageObjeto = imageObjeto;
//	}

	public int getPosX() {
		return posX;
	}

	public BufferedImage getImageObjeto() {
		return imageObjeto;
	}

	public void setPosX(int posX) {
		this.posX = posX;
	}

	public int getPosY() {
		return posY;
	}

	public void setPosY(int posY) {
		this.posY = posY;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}
}
