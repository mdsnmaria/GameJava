package model;

import java.awt.Rectangle;
import java.util.ArrayList;
// verificar o tamnho do arrylist setas
// adicionar nv seta e pegar o indice X baseado no tamanho do arraylist
//
public class Imagens extends SetasImagem{
	static ArrayList<Imagens> setas= new ArrayList<Imagens>();
	boolean isVisivel;
	boolean isBloqueda;
	static int posiXdireita[]= {385, 418, 450, 481, 514, 546};
	static int posiYdireita[]= {320, 320, 320, 320, 320, 320};
	static int posiXcima[]= {385, 418, 450, 481};
	static int posiYcima[]= {320, 320, 320, 320};
	static int posiXesquerda[]= {385, 418, 450, 481, 514, 546};
	static int posiYesquerda[]= {320, 320, 320, 320, 320, 320};
	static int posiXBaixo[]= {385, 418, 450, 481};
	static int posiYBaixo[]= {320, 320, 320, 320};
	
	
	static int fase2posXdireitaCorreta[]= {63, 96, 129, 161, 194, 226, 259, 292, 325, 356, 389, 422,  455, 488, 521, 553};
	static int fase2posYdireitaCorreta[]= {352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352};
	static int fase2posXesquerdaCorreta[]= {63, 96, 129, 161, 194, 226, 259, 292, 325, 356, 389, 422,  455, 488, 521, 553};
	static int fase2posYesquerdaCorreta[]= {352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352};
	static int fase2posXcimaCorreta[]= {63, 96, 129, 161, 194, 226, 259, 292, 325, 356, 389, 422,  455, 488, 521, 553};
	static int fase2posYcimaCorreta[]= {352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352};
	static int fase2posXbaixoCorreta[]= {63, 96, 129, 161, 194, 226, 259, 292, 325, 356, 389, 422,  455, 488, 521, 553};
	static int fase2posYbaixoCorreta[]= {352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352, 352};
	
	
	
	
	int direcaoSeta;
	// 1- direita; 2- cima ; 3- esquerda ; 4 baixo.
	
	//criar atributo dire��o e colocar no construtor do tipo inteiro
	public Imagens(String titulo, int posX, int posY, int width, int height, boolean status) {
		super(titulo, posX, posY, width, height);
		isVisivel= status;
		isBloqueda= true;
		
	}
	
	public Imagens(String titulo, int posX, int posY, int width, int height, boolean status, int direcao) {
		super(titulo, posX, posY, width, height);
		isVisivel= status;
		isBloqueda= true;
		this.direcaoSeta= direcao; //criar uma string ou int dire��o
		
	}

	
	@Override
	public Rectangle getBounds() {
		return new Rectangle(posX, posY, width, height);
	}

	public boolean isVisivel() {
		return isVisivel;
	}

	public void setVisivel(boolean isVisivel) {
		this.isVisivel = isVisivel;
	}

	public boolean isBloqueda() {
		return isBloqueda;
	}

	public void setBloqueda(boolean isBloqueda) {
		this.isBloqueda = isBloqueda;
	}

	public static ArrayList<Imagens> getSetas() {
		return setas;
	}

	public static void setSetas(ArrayList<Imagens> setas) {
		Imagens.setas = setas;
	}

	public static int[] getPosiX() {
		return posiXdireita;
	}

	public static int[] getPosiY() {
		return posiYdireita;
	}

	public int getDirecaoSeta() {
		return direcaoSeta;
	}

	public void setDirecaoSeta(int direcaoSeta) {
		this.direcaoSeta = direcaoSeta;
	}

	public static int[] getPosiXdireita() {
		return posiXdireita;
	}

	public static int[] getPosiYdireita() {
		return posiYdireita;
	}

	public static int[] getPosiXcima() {
		return posiXcima;
	}

	public static int[] getPosiYcima() {
		return posiYcima;
	}

	public static int[] getPosiXesquerda() {
		return posiXesquerda;
	}

	public static int[] getPosiYesquerda() {
		return posiYesquerda;
	}

	public static int[] getPosiXBaixo() {
		return posiXBaixo;
	}

	public static int[] getPosiYBaixo() {
		return posiYBaixo;
	}


	public static int[] getFase2posXdireitaCorreta() {
		return fase2posXdireitaCorreta;
	}

	public static int[] getFase2posYdireitaCorreta() {
		return fase2posYdireitaCorreta;
	}

	public static int[] getFase2posXesquerdaCorreta() {
		return fase2posXesquerdaCorreta;
	}

	public static int[] getFase2posYesquerdaCorreta() {
		return fase2posYesquerdaCorreta;
	}

	public static int[] getFase2posXcimaCorreta() {
		return fase2posXcimaCorreta;
	}

	public static int[] getFase2posYcimaCorreta() {
		return fase2posYcimaCorreta;
	}

	public static int[] getFase2posXbaixoCorreta() {
		return fase2posXbaixoCorreta;
	}

	public static int[] getFase2posYbaixoCorreta() {
		return fase2posYbaixoCorreta;
	}



}
