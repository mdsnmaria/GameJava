package model;

import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.swing.Timer;

public class Inimigo extends Sprite implements Runnable{
	// inplementar velocidade
	private int direcao = new Random().nextInt(4);
	Thread thread;
	private boolean isVisible;


	public Inimigo(String file, int aparencia, int colunasColums, int linhasRows, int posX, int posY, int larguraPers,
			int alturaPers) {
		super(file, aparencia, colunasColums, linhasRows, posX, posY, larguraPers, alturaPers);

		thread= new Thread(this);
		thread.start();
		isVisible= true;
	}

	@Override
	public void run() {
		while(true) {
			mover(direcao);
			try {
			Thread.sleep(1000);
		} catch (Exception e) {
			// TODO: handle exception
		}
			
		
		}
		
	}

	public void atualizaPosicao(int x, int y) {
		setPosX(x);
		setPosY(y);
	}

	public void mover(int direcao) {
		if (direcao == 0) {
			atualizaPosicao(getPosX(), getPosY()-4);
//			setAparecia(0);
		}
		if (direcao == 1) {
			atualizaPosicao(getPosX(), getPosY()+4);
//			setAparecia(1);
		}
		if (direcao == 2) {
			atualizaPosicao(getPosX()-4, getPosY());
//			setAparecia(2);
		}
		if (direcao == 3) {
			atualizaPosicao(getPosX()+4, getPosY());
//			setAparecia(3);
		}
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle(getPosX(), getPosY(), getLarguraWidth(), getAlturaHeight());
	}

	public int getDirecao() {
		return direcao;
	}

	public void setDirecao(int direcao) {
		this.direcao = direcao;
	}

	public boolean isVisible() {
		return isVisible;
	}

	public void setVisible(boolean isVisible) {
		this.isVisible = isVisible;
	}

	
}
