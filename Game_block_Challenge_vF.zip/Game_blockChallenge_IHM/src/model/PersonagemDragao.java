package model;

import java.awt.Rectangle;
import java.util.ArrayList;

public class PersonagemDragao extends Sprite {

	int direcaoDireita =0;
	public void setDirecaoDireita(int direcaoDireita) {
		
	}

	public PersonagemDragao(String file, int aparencia, int colunasColums, int linhasRows, int posX, int posY,
			int larguraPers, int alturaPers) {
		super(file, aparencia, colunasColums, linhasRows, posX, posY, larguraPers, alturaPers);
	}

	@Override
	public Rectangle getBounds() {
		return new Rectangle(getPosX() + 10, getPosY() + 10, getLarguraWidth() - 20, getAlturaHeight() - 20);
	

	}

	public int getDirecaoDireita() {
		return direcaoDireita;
	}


}
