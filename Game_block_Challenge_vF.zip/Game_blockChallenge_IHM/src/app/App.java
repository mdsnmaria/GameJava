package app;

import java.io.IOException;

import controller.ControllerTelaCenario1;
import controller.ControllerCen1CasteloAzul;
import controller.ControllerCen1CasteloNeve;
import controller.ControllerCen1CasteloVerd;
import controller.ControllerCen1CasteloVerm;
import controller.ControllerFase02;
import controller.ControllerGanhouJogo;
import controller.ControllerMenu;
import controller.ControllerSubFase;
import view.TelaCenario01Principal;
import view.TelaControle;

public class App {
	//melhorar colisao nas extremidades e nos troncos e colocar os inimigos, passar na frente do caule
	
	

	public static void main(String[] args) {
		TelaControle controle= new TelaControle();
		ControllerMenu menu = new ControllerMenu(controle);
		ControllerTelaCenario1 telaInicio = new ControllerTelaCenario1(controle);
		ControllerCen1CasteloVerd verd= new ControllerCen1CasteloVerd(controle);
		ControllerCen1CasteloVerm verm= new ControllerCen1CasteloVerm(controle);
		ControllerCen1CasteloAzul azul= new ControllerCen1CasteloAzul(controle);
		ControllerCen1CasteloNeve neve= new ControllerCen1CasteloNeve(controle);
		ControllerGanhouJogo ganhou= new ControllerGanhouJogo(controle);
		ControllerFase02 fase02 = new ControllerFase02(controle);
		ControllerSubFase subFase = new ControllerSubFase(controle);
		
	}
}
