package view;

import javax.swing.JFrame;

public abstract class TelaJframeAbstract extends JFrame{
	public static final int LARGURA= 640;
	public static final int ALTURA= 480;
	
	
	public TelaJframeAbstract() {
		super("Game");
		setSize(LARGURA, ALTURA);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		setUndecorated(true);
		setLayout(null);
	}

}
