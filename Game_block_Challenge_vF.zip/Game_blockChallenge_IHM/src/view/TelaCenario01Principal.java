package view;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;

import model.Imagens;
import model.PersonagemDragao;
import model.Sprite;
import model.TileMap;

public class TelaCenario01Principal extends TelaPanelAbstract {

	TileMap fundo, casteloVerd, casteloVerm, casteloAzul, casteloNeve, camColor1, camIncolor2, camIncolor3, camIncolor4,
			camColor2, camColor3, camColor4, camColorCompleto;
	BufferedImage tela;
	PersonagemDragao personagem;
	Imagens botaoExit, opcoes_sair, efeitoBlock;

	public static List<Rectangle> retangulosColisaoCasteloVerde;
	public static List<Rectangle> retangulosColisaoCasteloVerm;
	public static List<Rectangle> retangulosColisaoCasteloAzul;
	public static List<Rectangle> retangulosColisaoCasteloNeve;
	public static List<Rectangle> retangulosColisaoCamIncolor2;
	public static List<Rectangle> retangulosColisaoCamIncolor3;
	public static List<Rectangle> retangulosColisaoCamIncolor4;

	public static List<Rectangle> retangulosColisaoFundo;

	public TelaCenario01Principal() {

		fundo = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileCenario1/Fundo.txt", true);
		casteloVerd = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileCenario1/Castelo01verd.txt", true);
		casteloVerm = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileCenario1/Castelo01verm.txt", true);
		casteloAzul = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileCenario1/Castelo01Azul.txt", true);
		casteloNeve = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileCenario1/Castelo01Neve.txt", true);
		camColor1 = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileCenario1/CaminhoColor1.txt", true);
		camIncolor2 = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileCenario1/IncolorCaminho2.txt", true);
		camIncolor3 = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileCenario1/IncolorCaminho3.txt", true);
		camIncolor4 = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileCenario1/IncolorCaminho4.txt", true);
		camColor2 = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileCenario1/CaminhoColor2.txt", false);
		camColor3 = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileCenario1/CaminhoColor3.txt", false);
		camColor4 = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileCenario1/CaminhoColor4.txt", false);
		camColorCompleto = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileCenario1/CaminhoColorCompleto.txt", false);

		botaoExit = new Imagens("/res/exit.png", 590, 10, 32, 32, true);
		opcoes_sair = new Imagens("/res/opcoes.png", 230, 40, 374, 197, false);
		efeitoBlock= new Imagens("/res/TELA_EFEITO_BLOCK.png", 0, 0, 640, 480, false);
		personagem = new PersonagemDragao("/res/spriteDragaocomCor.png", 1, 4, 4, 283, 187, 40, 40);
//		inimigo1 = new Sprite("/res/inimigo.png", 1, 4, 4, 260, 150);

		fundo.montarMapa(640, 480);
		casteloVerd.montarMapa(640, 480);
		casteloVerm.montarMapa(640, 480);
		casteloAzul.montarMapa(640, 480);
		casteloNeve.montarMapa(640, 480);
		camColor1.montarMapa(640, 480);
		camIncolor2.montarMapa(640, 480);
		camIncolor3.montarMapa(640, 480);
		camIncolor4.montarMapa(640, 480);
		camColor2.montarMapa(640, 480);
		camColor3.montarMapa(640, 480);
		camColor4.montarMapa(640, 480);
		camColorCompleto.montarMapa(640, 480);

		retangulosColisaoCasteloVerde = casteloVerd.montarColisao();
		retangulosColisaoCasteloVerm = casteloVerm.montarColisao();
		retangulosColisaoCasteloAzul = casteloAzul.montarColisao();
		retangulosColisaoCasteloNeve = casteloNeve.montarColisao();
		retangulosColisaoFundo = fundo.montarColisaoFundo();

		retangulosColisaoCamIncolor2 = camIncolor2.montarColisaoIncolorCam2();
		retangulosColisaoCamIncolor3 = camIncolor3.montarColisaoIncolorCam3();
		retangulosColisaoCamIncolor4 = camIncolor4.montarColisaoIncolorCam4();

		tela = new BufferedImage(this.getWidth(), this.getHeight(), BufferedImage.TYPE_4BYTE_ABGR);
		setVisible(false);

	}

	@Override
	public void paint(Graphics g) {
		
		
		g.drawImage(fundo.getCamada(), 0, 0, null);
		g.drawImage(casteloVerd.getCamada(), 0, 0, null);
		g.drawImage(casteloVerm.getCamada(), 0, 0, null);
		g.drawImage(casteloAzul.getCamada(), 0, 0, null);
		g.drawImage(casteloNeve.getCamada(), 0, 0, null);
		g.drawImage(camColor1.getCamada(), 0, 0, null);
		g.drawImage(camIncolor2.getCamada(), 0, 0, null);
		g.drawImage(camIncolor3.getCamada(), 0, 0, null);
		g.drawImage(camIncolor4.getCamada(), 0, 0, null);

		if (camColor2.isVisivel()) {
			g.drawImage(camColor2.getCamada(), 0, 0, null);
		}
		if (camColor3.isVisivel()) {
			g.drawImage(camColor3.getCamada(), 0, 0, null);
		}
		if (camColor4.isVisivel()) {
			g.drawImage(camColor4.getCamada(), 0, 0, null);
		}
		if (camColorCompleto.isVisivel()) {
			g.drawImage(camColorCompleto.getCamada(), 0, 0, null);

		}
		g.drawImage(personagem.getSprites()[personagem.getAparecia()], personagem.getPosX(), personagem.getPosY(),
				null);
		
		g.drawImage(botaoExit.getImageObjeto(), botaoExit.getPosX(), botaoExit.getPosY(), null);

		if (opcoes_sair.isVisivel()) {
			g.drawImage(opcoes_sair.getImageObjeto(), opcoes_sair.getPosX(), opcoes_sair.getPosY(), null);
		}
		
		if (efeitoBlock.isVisivel()) {
			g.drawImage(efeitoBlock.getImageObjeto(), efeitoBlock.getPosX(), efeitoBlock.getPosY(), null);
		}


	}

	public BufferedImage getTela() {
		return tela;
	}

	public void setTela(BufferedImage tela) {
		this.tela = tela;
	}

	public TileMap getFundo() {
		return fundo;
	}

	public void setFundo(TileMap fundo) {
		this.fundo = fundo;
	}

	public TileMap getCamColor1() {
		return camColor1;
	}

	public void setCamColor1(TileMap camColor1) {
		this.camColor1 = camColor1;
	}

	public TileMap getCamIncolor2() {
		return camIncolor2;
	}

	public void setCamIncolor2(TileMap camIncolor2) {
		this.camIncolor2 = camIncolor2;
	}

	public TileMap getCamIncolor3() {
		return camIncolor3;
	}

	public void setCamIncolor3(TileMap camIncolor3) {
		this.camIncolor3 = camIncolor3;
	}

	public TileMap getCamIncolor4() {
		return camIncolor4;
	}

	public void setCamIncolor4(TileMap camIncolor4) {
		this.camIncolor4 = camIncolor4;
	}

	public static List<Rectangle> getRetangulosColisaoCasteloVerde() {
		return retangulosColisaoCasteloVerde;
	}

	public static List<Rectangle> getRetangulosColisaoFundo() {
		return retangulosColisaoFundo;
	}

	public TileMap getCasteloVerd() {
		return casteloVerd;
	}

	public void setCasteloVerd(TileMap casteloVerd) {
		this.casteloVerd = casteloVerd;
	}

	public TileMap getCasteloVerm() {
		return casteloVerm;
	}

	public void setCasteloVerm(TileMap casteloVerm) {
		this.casteloVerm = casteloVerm;
	}

	public TileMap getCasteloAzul() {
		return casteloAzul;
	}

	public void setCasteloAzul(TileMap casteloAzul) {
		this.casteloAzul = casteloAzul;
	}

	public TileMap getCaminhoColorCompleto() {
		return camColorCompleto;
	}

	public void setCaminhoColorCompleto(TileMap caminhoColorCompleto) {
		this.camColorCompleto = caminhoColorCompleto;
	}

	public TileMap getCamColor2() {
		return camColor2;
	}

	public void setCamColor2(TileMap camColor2) {
		this.camColor2 = camColor2;
	}

	public TileMap getCamColor3() {
		return camColor3;
	}

	public void setCamColor3(TileMap camColor3) {
		this.camColor3 = camColor3;
	}

	public TileMap getCamColor4() {
		return camColor4;
	}

	public void setCamColor4(TileMap camColor4) {
		this.camColor4 = camColor4;
	}

	public TileMap getCasteloNeve() {
		return casteloNeve;
	}

	public TileMap getCamColorCompleto() {
		return camColorCompleto;
	}

	public Imagens getEfeitoBlock() {
		return efeitoBlock;
	}

	public static List<Rectangle> getRetangulosColisaoCamIncolor2() {
		return retangulosColisaoCamIncolor2;
	}

	public static List<Rectangle> getRetangulosColisaoCamIncolor3() {
		return retangulosColisaoCamIncolor3;
	}

	public static List<Rectangle> getRetangulosColisaoCamIncolor4() {
		return retangulosColisaoCamIncolor4;
	}

	public Imagens getBotaoExit() {
		return botaoExit;
	}

	public Imagens getOpcoes_sair() {
		return opcoes_sair;
	}

	public void setCasteloNeve(TileMap casteloNeve) {
		this.casteloNeve = casteloNeve;
	}

	public static List<Rectangle> getRetangulosColisaoCasteloVerm() {
		return retangulosColisaoCasteloVerm;
	}

	public static List<Rectangle> getRetangulosColisaoCasteloAzul() {
		return retangulosColisaoCasteloAzul;
	}

	public static List<Rectangle> getRetangulosColisaoCasteloNeve() {
		return retangulosColisaoCasteloNeve;
	}

	public PersonagemDragao getPersonagem() {
		return personagem;
	}

	public void setPersonagem(PersonagemDragao personagem) {
		this.personagem = personagem;
	}

}
