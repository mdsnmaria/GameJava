package view;

public class TelaControle extends TelaJframeAbstract {
	private TelaCenario01Principal cenario1;
	private Cenario1CasteloVerde verde;
	private Cenario1CasteloVermelho vermelho;
	private Cenario1CasteloAzul azul;
	private Cenario1CasteloNeve neve;
	private TelaFase02 fase02;
	private SubFase2 subfase;
	private Tela_menu menu;
	private TelaGanhouJogo ganhouJogo;

	public TelaControle() {

		cenario1 = new TelaCenario01Principal();
		add(cenario1);
		
		verde = new Cenario1CasteloVerde();
		add(verde);
		
		azul= new Cenario1CasteloAzul();
		add(azul);
		
		vermelho = new Cenario1CasteloVermelho();
		add(vermelho);
		
		neve= new Cenario1CasteloNeve();
		add(neve);
		
		fase02= new TelaFase02();
		add(fase02);
		
		subfase= new SubFase2();
		add(subfase);
		
		menu= new Tela_menu();
		add(menu);
		
		ganhouJogo= new TelaGanhouJogo();
		add(ganhouJogo);
		
	}
	

	public TelaCenario01Principal getCenario1() {
		return cenario1;
	}

	public void setCenario1(TelaCenario01Principal cenario1) {
		this.cenario1 = cenario1;
	}

	public Cenario1CasteloVerde getVerde() {
		return verde;
	}

	public Cenario1CasteloAzul getAzul() {
		return azul;
	}

	public Cenario1CasteloVermelho getVermelho() {
		return vermelho;
	}

	public Cenario1CasteloNeve getNeve() {
		return neve;
	}

	public TelaFase02 getFase02() {
		return fase02;
	}


	public SubFase2 getSubfase() {
		return subfase;
	}


	public Tela_menu getMenu() {
		return menu;
	}


	public TelaGanhouJogo getGanhouJogo() {
		return ganhouJogo;
	}



}
