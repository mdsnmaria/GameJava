package view;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.List;

import model.PersonagemDragao;
import model.Imagens;
import model.Sprite;
import model.TileMap;

public class Cenario1CasteloVermelho extends TelaPanelAbstract {

	TileMap fundoVerm, casteloVerm, pinheiroVerm, colisaoVerm, pedrasVerm;
	BufferedImage tela;
	PersonagemDragao personagem;
	Imagens setaCima, botaoExit, opcoes_sair;
	

	public static List<Rectangle> retangulosColisaoTronco;
	public static List<Rectangle> retangulosColisaoCastelo;
	
	public Cenario1CasteloVermelho() {
		
		
		fundoVerm = new TileMap("/res_Fase1/tiledT2C1.png", 15, 20, 32, 32, "/tilesCenarioVermelho/FundoVerm.txt", true);
		pinheiroVerm = new TileMap("/res_Fase1/tiledT2C1.png", 15, 20, 32, 32, "/tilesCenarioVermelho/PinheiroVerm.txt", true);
		pedrasVerm= new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tilesCenarioVermelho/PedrasVerm.txt", true);	
		casteloVerm = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tilesCenarioVermelho/CasteloVerm.txt", true);
		colisaoVerm = new TileMap("/res_Fase1/tiledT2C1.png", 15, 20, 32, 32, "/tilesCenarioVermelho/ColisaoVerm.txt", true);
		
//		//personagem = new Sprite("/res/spriteAguia.png", 1, 4, 4, 50, 100);
		personagem = new PersonagemDragao("/res/spriteDragaocomCor.png", 1, 4, 4, 557, 80, 40, 40);
//		inimigo1 = new Sprite("/res/inimigo.png", 1, 4, 4, 260, 150);
		setaCima= new Imagens("/res/cima.png", posAleatoriaX(), posAleatoriaY(), 32, 32, true);
		
		botaoExit = new Imagens("/res/exit.png", 608, 5, 32, 32, true);
		opcoes_sair = new Imagens("/res/opcoes.png", 230, 40, 374, 197, false);
		
		fundoVerm.montarMapa(640, 480);
		casteloVerm.montarMapa(640, 480);
		pinheiroVerm.montarMapa(640, 480);
		colisaoVerm.montarMapa(640, 480);
		pedrasVerm.montarMapa(640, 480);
		
		retangulosColisaoCastelo= casteloVerm.montarColisao();
		retangulosColisaoTronco= colisaoVerm.montarColisaoCenarioVermelho();

		tela = new BufferedImage(this.getWidth(), this.getHeight(), BufferedImage.TYPE_4BYTE_ABGR);
		setVisible(false);
		
	}
	
	

	@Override
	public void paint(Graphics g) {	
		g.drawImage(fundoVerm.getCamada(), 0, 0, null);
		g.drawImage(colisaoVerm.getCamada(), 0, 0, null);
		g.drawImage(pedrasVerm.getCamada(), 0, 0, null);
		g.drawImage(casteloVerm.getCamada(), 0, 0, null);
		g.drawImage(personagem.getSprites()[personagem.getAparecia()], personagem.getPosX(),
				personagem.getPosY(), null);
		
		
		g.drawImage(pinheiroVerm.getCamada(), 0, 0, null);

		if(setaCima.isVisivel()) {
			g.drawImage(setaCima.getImageObjeto(), setaCima.getPosX(), setaCima.getPosY(), null);
		}
		
		g.drawImage(botaoExit.getImageObjeto(), botaoExit.getPosX(), botaoExit.getPosY(), null);

		if (opcoes_sair.isVisivel()) {
			g.drawImage(opcoes_sair.getImageObjeto(), opcoes_sair.getPosX(), opcoes_sair.getPosY(), null);
		}
	}
	
	private int posAleatoriaX() {
		return (int) (Math.random() * 522) ;

	}

	private int posAleatoriaY() {

		return (int) (Math.random() * 441);// gera pos aleatoria // calcula pra depois gerar o cast
	}

	public TileMap getFundo() {
		return fundoVerm;
	}



	public void setFundo(TileMap fundo) {
		this.fundoVerm = fundo;
	}



	public TileMap getCastelo() {
		return casteloVerm;
	}



	public void setCastelo(TileMap castelo) {
		this.casteloVerm = castelo;
	}



	public TileMap getPinheiro() {
		return pinheiroVerm;
	}



	public void setPinheiro(TileMap pinheiro) {
		this.pinheiroVerm = pinheiro;
	}



	public TileMap getColisao() {
		return colisaoVerm;
	}



	public void setColisao(TileMap colisao) {
		this.colisaoVerm = colisao;
	}



	public TileMap getPedras() {
		return pedrasVerm;
	}



	public void setPedras(TileMap pedras) {
		this.pedrasVerm = pedras;
	}



	public BufferedImage getTela() {
		return tela;
	}



	public void setTela(BufferedImage tela) {
		this.tela = tela;
	}

	public TileMap getFundoVerm() {
		return fundoVerm;
	}



	public void setFundoVerm(TileMap fundoVerm) {
		this.fundoVerm = fundoVerm;
	}



	public TileMap getCasteloVerm() {
		return casteloVerm;
	}



	public void setCasteloVerm(TileMap casteloVerm) {
		this.casteloVerm = casteloVerm;
	}



	public TileMap getPinheiroVerm() {
		return pinheiroVerm;
	}



	public void setPinheiroVerm(TileMap pinheiroVerm) {
		this.pinheiroVerm = pinheiroVerm;
	}



	public TileMap getColisaoVerm() {
		return colisaoVerm;
	}



	public void setColisaoVerm(TileMap colisaoVerm) {
		this.colisaoVerm = colisaoVerm;
	}



	public TileMap getPedrasVerm() {
		return pedrasVerm;
	}



	public void setPedrasVerm(TileMap pedrasVerm) {
		this.pedrasVerm = pedrasVerm;
	}



	public PersonagemDragao getPersonagem() {
		return personagem;
	}



	public void setPersonagem(PersonagemDragao personagem) {
		this.personagem = personagem;
	}



	public static List<Rectangle> getRetangulosColisaoCastelo() {
		return retangulosColisaoCastelo;
	}



	public Imagens getSeta() {
		return setaCima;
	}



	public void setSeta(Imagens seta) {
		this.setaCima = seta;
	}



	public Imagens getBotaoExit() {
		return botaoExit;
	}



	public Imagens getOpcoes_sair() {
		return opcoes_sair;
	}

}
