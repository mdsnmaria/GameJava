package view;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.List;

import model.PersonagemDragao;
import model.Imagens;
import model.Sprite;
import model.TileMap;

public class Cenario1CasteloNeve extends TelaPanelAbstract {

	TileMap fundo, castelo, pinheiro, colisaoCenario, colisaoTronco, pedras;
	BufferedImage tela;
	PersonagemDragao personagem;
	Imagens setaBaixo, botaoExit, opcoes_sair;
	

	public static List<Rectangle> retangulosColisaoTronco;
	public static List<Rectangle> retangulosColisaoCenario;
	public static List<Rectangle> retangulosColisaoCastelo;
	
	public Cenario1CasteloNeve() {
		
		
		fundo = new TileMap("/res_Fase1/tiledNeve.png", 15, 20, 32, 32, "/tilesCenarioNeve/FundoNeve.txt", true);
		pinheiro = new TileMap("/res_Fase1/tiledT2C1.png", 15, 20, 32, 32, "/tilesCenarioNeve/PinheiroNeve.txt", true);
		pedras= new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tilesCenarioNeve/PedrasNeve.txt", true);	
		castelo = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tilesCenarioNeve/CasteloNeve.txt", true);
		colisaoCenario = new TileMap("/res_Fase1/tiledNeve.png", 15, 20, 32, 32, "/tilesCenarioNeve/ColisaoNeve.txt", true);
		colisaoTronco = new TileMap("/res_Fase1/tiledT2C1.png", 15, 20, 32, 32, "/tilesCenarioNeve/ColisaoTroncoPinh.txt", true);
		
		botaoExit = new Imagens("/res/exit.png", 608, 5, 32, 32, true);
		opcoes_sair = new Imagens("/res/opcoes.png", 230, 40, 374, 197, false);
//		//personagem = new Sprite("/res/spriteAguia.png", 1, 4, 4, 50, 100);
		personagem = new PersonagemDragao("/res/spriteDragaocomCor.png", 1, 4, 4, 557, 80, 40, 40);
//		inimigo1 = new Sprite("/res/inimigo.png", 1, 4, 4, 260, 150);
		setaBaixo= new Imagens("/res/baixo.png", posAleatoriaX(), posAleatoriaY(), 32, 32, true);
		
		
		fundo.montarMapa(640, 480);
		castelo.montarMapa(640, 480);
		pinheiro.montarMapa(640, 480);
		colisaoCenario.montarMapa(640, 480);
		colisaoTronco.montarMapa(640, 480);
		pedras.montarMapa(640, 480);
		
		retangulosColisaoCastelo = castelo.montarColisao();
		retangulosColisaoTronco= colisaoTronco.montarColisaoTroncoNeve();
		retangulosColisaoCenario= colisaoCenario.montarColisaoCenarioNeve();

		tela = new BufferedImage(this.getWidth(), this.getHeight(), BufferedImage.TYPE_4BYTE_ABGR);
		setVisible(false);
		
	}
	
	

	@Override
	public void paint(Graphics g) {	
		g.drawImage(fundo.getCamada(), 0, 0, null);
		g.drawImage(colisaoCenario.getCamada(), 0, 0, null);
		g.drawImage(colisaoTronco.getCamada(), 0, 0, null);
		g.drawImage(pedras.getCamada(), 0, 0, null);
		g.drawImage(castelo.getCamada(), 0, 0, null);
		g.drawImage(personagem.getSprites()[personagem.getAparecia()], personagem.getPosX(),
				personagem.getPosY(), null);
		
		
		g.drawImage(pinheiro.getCamada(), 0, 0, null);
	
		if(setaBaixo.isVisivel()) {
			g.drawImage(setaBaixo.getImageObjeto(), setaBaixo.getPosX(), setaBaixo.getPosY(), null);
		}
		
		g.drawImage(botaoExit.getImageObjeto(), botaoExit.getPosX(), botaoExit.getPosY(), null);

		if (opcoes_sair.isVisivel()) {
			g.drawImage(opcoes_sair.getImageObjeto(), opcoes_sair.getPosX(), opcoes_sair.getPosY(), null);
		}
	}

	private int posAleatoriaX() {
		return (int) (Math.random() * 522);

	}

	private int posAleatoriaY() {

		return (int) (Math.random() * 441);// gera pos aleatoria // calcula pra depois gerar o cast
	}


	public TileMap getFundo() {
		return fundo;
	}



	public void setFundo(TileMap fundo) {
		this.fundo = fundo;
	}



	public TileMap getCastelo() {
		return castelo;
	}



	public void setCastelo(TileMap castelo) {
		this.castelo = castelo;
	}



	public TileMap getPinheiro() {
		return pinheiro;
	}



	public void setPinheiro(TileMap pinheiro) {
		this.pinheiro = pinheiro;
	}



	public TileMap getColisao() {
		return colisaoCenario;
	}



	public void setColisao(TileMap colisao) {
		this.colisaoCenario = colisao;
	}



	public TileMap getPedras() {
		return pedras;
	}



	public void setPedras(TileMap pedras) {
		this.pedras = pedras;
	}



	public BufferedImage getTela() {
		return tela;
	}



	public void setTela(BufferedImage tela) {
		this.tela = tela;
	}


	public PersonagemDragao getPersonagem() {
		return personagem;
	}



	public void setPersonagem(PersonagemDragao personagem) {
		this.personagem = personagem;
	}



	public static List<Rectangle> getRetangulosColisaoCastelo() {
		return retangulosColisaoCastelo;
	}



	public TileMap getColisaoTronco() {
		return colisaoTronco;
	}



	public void setColisaoTronco(TileMap colisaoTronco) {
		this.colisaoTronco = colisaoTronco;
	}



	public Imagens getSeta() {
		return setaBaixo;
	}



	public void setSeta(Imagens seta) {
		this.setaBaixo = seta;
	}



	public Imagens getBotaoExit() {
		return botaoExit;
	}



	public Imagens getOpcoes_sair() {
		return opcoes_sair;
	}



}
