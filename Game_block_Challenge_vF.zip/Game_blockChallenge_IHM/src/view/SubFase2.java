package view;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.List;

import model.PersonagemDragao;
import model.Imagens;
import model.TileMap;

public class SubFase2 extends TelaPanelAbstract {

	TileMap fundo, portaCima, portaBaixo, portaEsquerda, portaDireita, camCima, camBaixo, camDireita, camEsquerda;
	BufferedImage tela;
	PersonagemDragao personagem;
	Imagens setaDireita, setaEsquerda, setaCima, setaBaixo, botaoPlay,
	botaoExit, opcoes_sair, aviso_setas, aviso_play;
	public static List<Rectangle> retangulosColisaoPortaDireita;
	public static List<Rectangle> retangulosColisaoPortaEsquerda;
	public static List<Rectangle> retangulosColisaoPortaCima;
	public static List<Rectangle> retangulosColisaoPortaBaixo;
	
	public SubFase2() {
		fundo = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileSubFase/FundoSubFase.txt", true);
		portaCima = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileSubFase/portaCima.txt", false);
		portaBaixo = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileSubFase/portaBaixo.txt", false);
		portaDireita = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileSubFase/portaDireita.txt", true);
		portaEsquerda = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileSubFase/portaEsquerda.txt", false);
		camCima = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileSubFase/camCima.txt", false);
		camBaixo = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileSubFase/camBaixo.txt", false);
		camDireita = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileSubFase/camDireita.txt", true);
		camEsquerda = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tileSubFase/camEsquerda.txt", false);

		personagem = new PersonagemDragao("/res/spriteDragaocomCor.png", 1, 4, 4, 315, 215, 40, 40);
		setaDireita = new Imagens("/res/direita.png", 450, 370, 32, 32, true);
		setaEsquerda = new Imagens("/res/esquerda.png", 450, 370, 32, 32, false);
		setaCima = new Imagens("/res/cima.png", 450, 370, 32, 32, false);
		setaBaixo = new Imagens("/res/baixo.png", 450, 370, 32, 32, false);
		botaoPlay = new Imagens("/res/green-play.png", 483, 370, 32, 32, true);
		botaoExit = new Imagens("/res/exit.png", 590, 10, 32, 32, true);
		opcoes_sair = new Imagens("/res/opcoes.png", 230, 40, 374, 197, false);
		aviso_setas = new Imagens("/res/aviso_setas.png", 70, 150, 492, 151, false);
		aviso_play = new Imagens("/res/aviso_play.png", 70, 150, 432, 136, false);
		
		retangulosColisaoPortaDireita = portaDireita.montarColisaoPortaSub2();
		retangulosColisaoPortaCima = portaCima.montarColisaoPortaSub2();
		retangulosColisaoPortaBaixo = portaBaixo.montarColisaoPortaSub2();
		retangulosColisaoPortaEsquerda = portaEsquerda.montarColisaoPortaSub2();
		
		fundo.montarMapa(640, 480);
		portaCima.montarMapa(640, 480);
		portaBaixo.montarMapa(640, 480);
		portaDireita.montarMapa(640, 480);
		portaEsquerda.montarMapa(640, 480);
		camCima.montarMapa(640, 480);
		camBaixo.montarMapa(640, 480);
		camDireita.montarMapa(640, 480);
		camEsquerda.montarMapa(640, 480);

		tela = new BufferedImage(this.getWidth(), this.getHeight(), BufferedImage.TYPE_4BYTE_ABGR);

		setVisible(false);
	}

	@Override
	public void paint(Graphics g) {
		g.drawImage(fundo.getCamada(), 0, 0, null);
		if (camDireita.isVisivel()) {
			g.drawImage(camDireita.getCamada(), 0, 0, null);
		}
		
		if (camEsquerda.isVisivel()) {
			g.drawImage(camEsquerda.getCamada(), 0, 0, null);
		}
		if (camCima.isVisivel()) {
			g.drawImage(camCima.getCamada(), 0, 0, null);
		}
		if (camBaixo.isVisivel()) {
			g.drawImage(camBaixo.getCamada(), 0, 0, null);
		}
		
		if(portaDireita.isVisivel()) {
			g.drawImage(portaDireita.getCamada(), 0, 0, null);
		}
		
		if (portaEsquerda.isVisivel()) {
			g.drawImage(portaEsquerda.getCamada(), 0, 0, null);
		}
		if (portaCima.isVisivel()) {
			g.drawImage(portaCima.getCamada(), 0, 0, null);
		}
		if (portaBaixo.isVisivel()) {
			g.drawImage(portaBaixo.getCamada(), 0, 0, null);
		}

		g.drawImage(personagem.getSprites()[personagem.getAparecia()], personagem.getPosX(), personagem.getPosY(),
				null);

		g.drawImage(botaoPlay.getImageObjeto(), botaoPlay.getPosX(), botaoPlay.getPosY(), null);

		if(setaDireita.isVisivel()) {
			g.drawImage(setaDireita.getImageObjeto(), setaDireita.getPosX(), setaDireita.getPosY(), null);
		}

		if (setaEsquerda.isVisivel()) {
			g.drawImage(setaEsquerda.getImageObjeto(), setaEsquerda.getPosX(), setaEsquerda.getPosY(), null);

		}
		
		if (setaCima.isVisivel()) {
			g.drawImage(setaCima.getImageObjeto(), setaCima.getPosX(), setaCima.getPosY(), null);

		}
		
		if (setaBaixo.isVisivel()) {
			g.drawImage(setaBaixo.getImageObjeto(), setaBaixo.getPosX(), setaBaixo.getPosY(), null);

		}
		
		g.drawImage(botaoExit.getImageObjeto(), botaoExit.getPosX(), botaoExit.getPosY(), null);
		
		if(opcoes_sair.isVisivel()){
			g.drawImage(opcoes_sair.getImageObjeto(), opcoes_sair.getPosX(), opcoes_sair.getPosY(), null);	
		}
		
		if(aviso_setas.isVisivel()){
			g.drawImage(aviso_setas.getImageObjeto(), aviso_setas.getPosX(), aviso_setas.getPosY(), null);	
		}
		
		if(aviso_play.isVisivel()){
			g.drawImage(aviso_play.getImageObjeto(), aviso_play.getPosX(), aviso_play.getPosY(), null);	
		}
		
		for (int i = 0; i < Imagens.getSetas().size(); i++) {
			Imagens seta = Imagens.getSetas().get(i);
			if (seta.isVisivel()) {
				g.drawImage(seta.getImageObjeto(), seta.getPosX(), seta.getPosY(), null);
			}

		}

	}
	public Imagens getBotaoExit() {
		return botaoExit;
	}

	public void setBotaoExit(Imagens botaoExit) {
		this.botaoExit = botaoExit;
	}

	public TileMap getFundo() {
		return fundo;
	}

	public void setFundo(TileMap fundo) {
		this.fundo = fundo;
	}

	public TileMap getPortaCima() {
		return portaCima;
	}

	public void setPortaCima(TileMap portaCima) {
		this.portaCima = portaCima;
	}

	public TileMap getPortaBaixo() {
		return portaBaixo;
	}

	public void setPortaBaixo(TileMap portaBaixo) {
		this.portaBaixo = portaBaixo;
	}

	public TileMap getPortaEsquerda() {
		return portaEsquerda;
	}

	public void setPortaEsquerda(TileMap portaEsquerda) {
		this.portaEsquerda = portaEsquerda;
	}

	public TileMap getPortaDireita() {
		return portaDireita;
	}

	public void setPortaDireita(TileMap portaDireita) {
		this.portaDireita = portaDireita;
	}

	public TileMap getCamCima() {
		return camCima;
	}

	public void setCamCima(TileMap camCima) {
		this.camCima = camCima;
	}

	public TileMap getCamBaixo() {
		return camBaixo;
	}

	public void setCamBaixo(TileMap camBaixo) {
		this.camBaixo = camBaixo;
	}

	public TileMap getCamDireita() {
		return camDireita;
	}

	public void setCamDireita(TileMap camDireita) {
		this.camDireita = camDireita;
	}

	public TileMap getCamEsquerda() {
		return camEsquerda;
	}

	public void setCamEsquerda(TileMap camEsquerda) {
		this.camEsquerda = camEsquerda;
	}

	public BufferedImage getTela() {
		return tela;
	}

	public void setTela(BufferedImage tela) {
		this.tela = tela;
	}

	public PersonagemDragao getPersonagem() {
		return personagem;
	}

	public void setPersonagem(PersonagemDragao personagem) {
		this.personagem = personagem;
	}

	public Imagens getSetaDireita() {
		return setaDireita;
	}

	public void setSetaDireita(Imagens setaDireita) {
		this.setaDireita = setaDireita;
	}

	public Imagens getSetaEsquerda() {
		return setaEsquerda;
	}

	public Imagens getSetaCima() {
		return setaCima;
	}

	public Imagens getSetaBaixo() {
		return setaBaixo;
	}

	public Imagens getAviso_play() {
		return aviso_play;
	}

	public Imagens getBotaoPlay() {
		return botaoPlay;
	}



	public void setBotaoPlay(Imagens botaoPlay) {
		this.botaoPlay = botaoPlay;
	}

	public Imagens getOpcoes_sair() {
		return opcoes_sair;
	}

	public void setOpcoes_sair(Imagens opcoes_sair) {
		this.opcoes_sair = opcoes_sair;
	}

	public Imagens getAviso_setas() {
		return aviso_setas;
	}

	public static List<Rectangle> getRetangulosColisaoPortaDireita() {
		return retangulosColisaoPortaDireita;
	}

	public static List<Rectangle> getRetangulosColisaoPortaEsquerda() {
		return retangulosColisaoPortaEsquerda;
	}

	public static List<Rectangle> getRetangulosColisaoPortaCima() {
		return retangulosColisaoPortaCima;
	}

	public static List<Rectangle> getRetangulosColisaoPortaBaixo() {
		return retangulosColisaoPortaBaixo;
	}

}
