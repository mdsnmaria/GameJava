package view;


import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.List;

import model.PersonagemDragao;
import model.Imagens;
import model.TileMap;

public class TelaFase02 extends TelaPanelAbstract {

	TileMap fundo, cercado, saida, caminho;
	BufferedImage tela;
	PersonagemDragao personagem;
	Imagens setaEsquerda, setaDireita, setaBaixo, setaCima, setaPlay, excluir, botaoExit2, opcoes_sair, aviso_setas,
			aviso_play, excluir_sem_seta;

	public static List<Rectangle> retangulosColisaoPorta;
	public static List<Rectangle> retangulosColisaoFundo;

	public TelaFase02() {

		fundo = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/fase02/FundoFase2.txt", true);
		caminho = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/fase02/CaminhoColor.txt", true);
		cercado = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/fase02/Cercado.txt", true);
		saida = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/fase02/Saida.txt", true);

		personagem = new PersonagemDragao("/res/spriteDragaocomCor.png", 1, 4, 4, 285, 150, 40, 40);

		setaPlay = new Imagens("/res/green-play.png", 234, 398, 32, 32, true);
		setaEsquerda = new Imagens("/res/esquerda.png", 284, 398, 32, 32, true);
		setaDireita = new Imagens("/res/direita.png", 334, 398, 32, 32, true);
		setaCima = new Imagens("/res/cima.png", 384, 398, 32, 32, true);
		setaBaixo = new Imagens("/res/baixo.png", 434, 398, 32, 32, true);
		excluir = new Imagens("/res/excluir.png", 484, 398, 32, 32, true);

		fundo.montarMapa(640, 480);
		cercado.montarMapa(640, 480);
		saida.montarMapa(640, 480);
		caminho.montarMapa(640, 480);

		botaoExit2 = new Imagens("/res/exit.png", 590, 10, 32, 32, true);
		opcoes_sair = new Imagens("/res/opcoes.png", 230, 40, 374, 197, false);
		aviso_setas = new Imagens("/res/aviso_setas.png", 70, 150, 492, 151, false);
		aviso_play = new Imagens("/res/aviso_play.png", 70, 150, 432, 136, false);
		excluir_sem_seta = new Imagens("/res/aleta_excluir_sem_seta.png", 140, 150, 391, 154, false);

		retangulosColisaoFundo = fundo.montarColisaoFundo();
		retangulosColisaoPorta = saida.montarColisaoPortaSub2();

		tela = new BufferedImage(this.getWidth(), this.getHeight(), BufferedImage.TYPE_4BYTE_ABGR);

//		setVisible(true);
		setVisible(false);

	}

	@Override
	public void paint(Graphics g) {
		g.drawImage(fundo.getCamada(), 0, 0, null);
		g.drawImage(caminho.getCamada(), 0, 0, null);
		g.drawImage(saida.getCamada(), 0, 0, null);
		g.drawImage(cercado.getCamada(), 0, 0, null);

		g.drawImage(personagem.getSprites()[personagem.getAparecia()], personagem.getPosX(), personagem.getPosY(),
				null);

		g.drawImage(setaPlay.getImageObjeto(), setaPlay.getPosX(), setaPlay.getPosY(), null);

		g.drawImage(setaEsquerda.getImageObjeto(), setaEsquerda.getPosX(), setaEsquerda.getPosY(), null);

		g.drawImage(setaDireita.getImageObjeto(), setaDireita.getPosX(), setaDireita.getPosY(), null);

		g.drawImage(setaCima.getImageObjeto(), setaCima.getPosX(), setaCima.getPosY(), null);

		g.drawImage(setaBaixo.getImageObjeto(), setaBaixo.getPosX(), setaBaixo.getPosY(), null);

		g.drawImage(excluir.getImageObjeto(), excluir.getPosX(), excluir.getPosY(), null);

		g.drawImage(botaoExit2.getImageObjeto(), botaoExit2.getPosX(), botaoExit2.getPosY(), null);

		if (opcoes_sair.isVisivel()) {
			g.drawImage(opcoes_sair.getImageObjeto(), opcoes_sair.getPosX(), opcoes_sair.getPosY(), null);
		}

		if (aviso_setas.isVisivel()) {
			g.drawImage(aviso_setas.getImageObjeto(), aviso_setas.getPosX(), aviso_setas.getPosY(), null);
		}

		if (aviso_play.isVisivel()) {
			g.drawImage(aviso_play.getImageObjeto(), aviso_play.getPosX(), aviso_play.getPosY(), null);
		}

		if (excluir_sem_seta.isVisivel()) {
			g.drawImage(excluir_sem_seta.getImageObjeto(), excluir_sem_seta.getPosX(),
					excluir_sem_seta.getPosY(), null);
		}

		for (int i = 0; i < Imagens.getSetas().size(); i++) {
			Imagens seta = Imagens.getSetas().get(i);
			if (seta.isVisivel()) {
				g.drawImage(seta.getImageObjeto(), seta.getPosX(), seta.getPosY(), null);
			}

		}
	}

	public TileMap getFundo() {
		return fundo;
	}

	public TileMap getCercado() {
		return cercado;
	}

	public TileMap getSaida() {
		return saida;
	}

	public TileMap getCaminho() {
		return caminho;
	}

	public BufferedImage getTela() {
		return tela;
	}

	public PersonagemDragao getPersonagem() {
		return personagem;
	}

	public Imagens getSetaEsquerda() {
		return setaEsquerda;
	}

	public Imagens getSetaDireita() {
		return setaDireita;
	}

	public Imagens getSetaBaixo() {
		return setaBaixo;
	}

	public Imagens getSetaCima() {
		return setaCima;
	}

	public Imagens getSetaPlay() {
		return setaPlay;
	}

	public Imagens getSetaExit() {
		return excluir;
	}

	public Imagens getBotaoExit2() {
		return botaoExit2;
	}

	public Imagens getOpcoes_sair() {
		return opcoes_sair;
	}

	public Imagens getAviso_setas() {
		return aviso_setas;
	}

	public Imagens getAviso_play() {
		return aviso_play;
	}

	public static List<Rectangle> getRetangulosColisaoPorta() {
		return retangulosColisaoPorta;
	}

	public Imagens getExcluir() {
		return excluir;
	}

	public Imagens getExcluir_sem_seta() {
		return excluir_sem_seta;
	}

	public static List<Rectangle> getRetangulosColisaoFundo() {
		return retangulosColisaoFundo;
	}

}
