package view;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;

import model.Inimigo;
import model.PersonagemDragao;
import model.Imagens;
//import model.OvoInteiro;
//import model.PersonagensCenario;
import model.Sprite;
import model.TileMap;

public class Cenario1CasteloVerde extends TelaPanelAbstract {

	private TileMap fundo, castelo, pinheiro, colisao, pedras;
	private BufferedImage tela;
	private Sprite personagem;
//	private Sprite inimigo1;
	private ArrayList<Inimigo> inimigos = new ArrayList<Inimigo>();
	Imagens setaDireita, botaoExit, opcoes_sair;

	public static List<Rectangle> retangulosColisaoTronco;
	public static List<Rectangle> retangulosColisaoCastelo;
	

	public Cenario1CasteloVerde() {

		fundo = new TileMap("/res_Fase1/tiledT2C1.png", 15, 20, 32, 32, "/tilesCenarioVerde/FundoF1.txt", true);
		pinheiro = new TileMap("/res_Fase1/tiledT2C1.png", 15, 20, 32, 32, "/tilesCenarioVerde/PinheiroF1.txt", true);
		pedras = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tilesCenarioVerde/PedrasF1.txt", true);
		castelo = new TileMap("/res/tiled.png", 15, 20, 32, 32, "/tilesCenarioVerde/CasteloF1.txt", true);
		colisao = new TileMap("/res_Fase1/tiledT2C1.png", 15, 20, 32, 32, "/tilesCenarioVerde/ColisaoF1.txt", true);

//		//personagem = new Sprite("res/spriteAguia.png", 1, 4, 4, 50, 100);
		personagem = new PersonagemDragao("/res/spriteDragaocomCor.png", 1, 4, 4, 557, 100, 40, 40);
		inimigos.add(new Inimigo("/res/inimigo.png", 1, 4, 4, posAleatoriaX(), posAleatoriaY(), 40, 40));
		inimigos.add(new Inimigo("/res/inimigo.png", 1, 4, 4, posAleatoriaX(), posAleatoriaY(), 40, 40));
		inimigos.add(new Inimigo("/res/inimigo.png", 1, 4, 4, 557, 73, 40, 40));
		setaDireita = new Imagens("/res/direita.png", posAleatoriaX(), posAleatoriaY(), 32, 32, true);

		botaoExit = new Imagens("/res/exit.png", 608, 5, 32, 32, true);
		opcoes_sair = new Imagens("/res/opcoes.png", 230, 40, 374, 197, false);
		
		fundo.montarMapa(640, 480);
		castelo.montarMapa(640, 480);
		pinheiro.montarMapa(640, 480);
		colisao.montarMapa(640, 480);
		pedras.montarMapa(640, 480);

		retangulosColisaoCastelo = castelo.montarColisao();
		retangulosColisaoTronco = colisao.montarColisaoCenarioVerde();

		tela = new BufferedImage(this.getWidth(), this.getHeight(), BufferedImage.TYPE_4BYTE_ABGR);

		setVisible(false);
	}

	@Override
	public void paint(Graphics g) {
		g.drawImage(fundo.getCamada(), 0, 0, null);
		g.drawImage(colisao.getCamada(), 0, 0, null);
		g.drawImage(pedras.getCamada(), 0, 0, null);
		g.drawImage(castelo.getCamada(), 0, 0, null);

		for (Sprite inim : inimigos) {
				g.drawImage(inim.getSprites()[inim.getAparecia()], inim.getPosX(), inim.getPosY(), null);
		
		}

		g.drawImage(personagem.getSprites()[personagem.getAparecia()], personagem.getPosX(), personagem.getPosY(),
				null);

		g.drawImage(pinheiro.getCamada(), 0, 0, null);

		if (setaDireita.isVisivel()) {
			g.drawImage(setaDireita.getImageObjeto(), setaDireita.getPosX(), setaDireita.getPosY(), null);
		}
		
		g.drawImage(botaoExit.getImageObjeto(), botaoExit.getPosX(), botaoExit.getPosY(), null);

		if (opcoes_sair.isVisivel()) {
			g.drawImage(opcoes_sair.getImageObjeto(), opcoes_sair.getPosX(), opcoes_sair.getPosY(), null);
		}

	}

	private int posAleatoriaX() {
		return (int) (Math.random() * 522);

	}

	private int posAleatoriaY() {

		return (int) (Math.random() * 441);// gera pos aleatoria // calcula pra depois gerar o cast
	}

	public TileMap getFundo() {
		return fundo;
	}

	public void setFundo(TileMap fundo) {
		this.fundo = fundo;
	}

	public TileMap getCastelo() {
		return castelo;
	}

	public void setCastelo(TileMap castelo) {
		this.castelo = castelo;
	}

	public TileMap getPinheiro() {
		return pinheiro;
	}

	public void setPinheiro(TileMap pinheiro) {
		this.pinheiro = pinheiro;
	}

	public TileMap getColisao() {
		return colisao;
	}

	public void setColisao(TileMap colisao) {
		this.colisao = colisao;
	}

	public TileMap getPedras() {
		return pedras;
	}

	public void setPedras(TileMap pedras) {
		this.pedras = pedras;
	}

	public BufferedImage getTela() {
		return tela;
	}

	public void setTela(BufferedImage tela) {
		this.tela = tela;
	}

	public Sprite getPersonagem() {
		return personagem;
	}

	public void setPersonagem(Sprite personagem) {
		this.personagem = personagem;
	}


	public static List<Rectangle> getRetangulosColisaoCastelo() {
		return retangulosColisaoCastelo;
	}

	public ArrayList<Inimigo> getInimigos() {
		return inimigos;
	}

	public void setInimigos(ArrayList<Inimigo> inimigos) {
		this.inimigos = inimigos;
	}


	public Imagens getSeta() {
		return setaDireita;
	}

	public void setSeta(Imagens seta) {
		this.setaDireita = seta;
	}

	public static List<Rectangle> getRetangulosColisaoTronco() {
		return retangulosColisaoTronco;
	}

	public Imagens getBotaoExit() {
		return botaoExit;
	}

	public Imagens getOpcoes_sair() {
		return opcoes_sair;
	}

}
