package view;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import model.Imagens;

public class TelaGanhouJogo extends TelaPanelAbstract{
	
	Imagens botaoExit2, ganhou_jogo, opcoes_sair;
	BufferedImage tela;
	
	public TelaGanhouJogo() {
		
		botaoExit2 = new Imagens("/res/exit.png", 590, 10, 32, 32, true);
		ganhou_jogo = new Imagens("/res/ganhouJogo.png", 0, 0, 640, 480, true);
		opcoes_sair = new Imagens("/res/opcoes.png", 230, 40, 374, 197, false);
		tela = new BufferedImage(this.getWidth(), this.getHeight(), BufferedImage.TYPE_4BYTE_ABGR);
		
		setVisible(false);
		
	}
	@Override
	public void paint(Graphics g) {
		g.drawImage(botaoExit2.getImageObjeto(), botaoExit2.getPosX(), botaoExit2.getPosY(), null);
		if (ganhou_jogo.isVisivel()) {
			g.drawImage(ganhou_jogo.getImageObjeto(), ganhou_jogo.getPosX(), ganhou_jogo.getPosY(), null);
		}
		
		if(opcoes_sair.isVisivel()){
			g.drawImage(opcoes_sair.getImageObjeto(), opcoes_sair.getPosX(), opcoes_sair.getPosY(), null);	
		}
		
		g.drawImage(botaoExit2.getImageObjeto(), botaoExit2.getPosX(), botaoExit2.getPosY(), null);

	}
	
	
	public Imagens getOpcoes_sair() {
		return opcoes_sair;
	}
	public BufferedImage getTela() {
		return tela;
	}
	public Imagens getBotaoExit2() {
		return botaoExit2;
	}
	public Imagens getGanhou_jogo() {
		return ganhou_jogo;
	}
	
}
