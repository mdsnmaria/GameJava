package view;

import javax.swing.JPanel;

public abstract class TelaPanelAbstract extends JPanel{
	
	public TelaPanelAbstract() {
		setSize(TelaJframeAbstract.LARGURA, TelaJframeAbstract.ALTURA);
		setLayout(null);
		setVisible(false);
	}

}
