package view;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

import model.Imagens;

public class Tela_menu extends TelaPanelAbstract{
	Imagens menu, historiaJogo, ajuda1, ajuda2;
	BufferedImage tela;

	public Tela_menu() {
		//colocar try catch nas imagens
		menu = new Imagens("/res/MenuMockup.png", 0, 0, 640, 480, true);
		historiaJogo = new Imagens("/res/HistoriaJogo.png", 0, 0, 640, 480, false);
		ajuda1 = new Imagens("/res/ajuda01.png", 0, 0, 640, 480, false);
		ajuda2 = new Imagens("/res/ajuda02.png", 0, 0, 640, 480, false);
		
		tela = new BufferedImage(this.getWidth(), this.getHeight(), BufferedImage.TYPE_4BYTE_ABGR);

		setVisible(true);
	}
	@Override
	public void paint(Graphics g) {
		if(menu.isVisivel()) {
			g.drawImage(menu.getImageObjeto(), menu.getPosX(), menu.getPosY(), null);
		}
		
		if(historiaJogo.isVisivel()) {
			g.drawImage(historiaJogo.getImageObjeto(), historiaJogo.getPosX(), historiaJogo.getPosY(), null);
		}
		
		if(ajuda1.isVisivel()) {
			g.drawImage(ajuda1.getImageObjeto(), ajuda1.getPosX(), ajuda1.getPosY(), null);
		}
		
		if(ajuda2.isVisivel()) {
			g.drawImage(ajuda2.getImageObjeto(), ajuda2.getPosX(), ajuda2.getPosY(), null);
		}
	}
	public Imagens getMenu() {
		return menu;
	}
	public BufferedImage getTela() {
		return tela;
	}
	public Imagens getHistoriaJogo() {
		return historiaJogo;
	}
	public Imagens getAjuda1() {
		return ajuda1;
	}
	public Imagens getAjuda2() {
		return ajuda2;
	}
}
